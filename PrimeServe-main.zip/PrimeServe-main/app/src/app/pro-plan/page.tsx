import Link from "next/link";
import {
    ChevronRight,
    CheckCircle2,
    X,
    Star,
    ArrowRight,
    Zap,
    Crown,
} from "lucide-react";

const plans = [
    {
        name: "Free",
        price: "₹0",
        period: "forever",
        description: "Get started with standard procurement features.",
        icon: Zap,
        featured: false,
        features: [
            { text: "Access to all 395+ products", included: true },
            { text: "Bulk pricing tiers", included: true },
            { text: "GST-compliant invoicing (Zoho)", included: true },
            { text: "Standard delivery (3–5 days)", included: true },
            { text: "45-day credit terms", included: true },
            { text: "Email & phone support", included: true },
            { text: "5% discount on all orders", included: false },
            { text: "60-day credit terms", included: false },
            { text: "Dedicated account manager", included: false },
            { text: "Priority order processing", included: false },
            { text: "Exclusive monthly deals", included: false },
            { text: "Free delivery on all orders", included: false },
        ],
    },
    {
        name: "Pro",
        price: null,
        period: null,
        description: "Maximum savings and premium support for growing businesses.",
        icon: Crown,
        featured: true,
        tiers: [
            { label: "Monthly", price: "₹1,999", period: "/month" },
            { label: "Quarterly", price: "₹4,999", period: "/quarter", badge: "Save 17%" },
            { label: "Annual", price: "₹14,999", period: "/year", badge: "Save 38%" },
        ],
        features: [
            { text: "Access to all 395+ products", included: true },
            { text: "Bulk pricing tiers", included: true },
            { text: "GST-compliant invoicing (Zoho)", included: true },
            { text: "Standard delivery (3–5 days)", included: true },
            { text: "45-day credit terms", included: true },
            { text: "Email & phone support", included: true },
            { text: "5% discount on all orders", included: true },
            { text: "60-day credit terms", included: true },
            { text: "Dedicated account manager", included: true },
            { text: "Priority order processing", included: true },
            { text: "Exclusive monthly deals", included: true },
            { text: "Free delivery on all orders", included: true },
        ],
    },
];

export default function ProPlanPage() {
    return (
        <>
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary">Home</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">Pro Plan</span>
                    </nav>
                </div>
            </div>

            {/* Hero */}
            <section className="bg-gradient-to-br from-primary via-primary-dark to-[#0F172A] text-white section-padding">
                <div className="container-custom text-center max-w-3xl mx-auto">
                    <span className="badge badge-pro mb-4 text-sm">⭐ Pro Plan</span>
                    <h1 className="text-3xl md:text-4xl font-bold mb-4">
                        Save More. Get More. Grow More.
                    </h1>
                    <p className="text-white/80 text-lg leading-relaxed">
                        Upgrade to PrimeServe Pro and unlock 5% discount on every order, extended
                        credit terms, dedicated support, and exclusive deals.
                    </p>
                </div>
            </section>

            {/* Plans Comparison */}
            <section className="section-padding">
                <div className="container-custom">
                    <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto">
                        {plans.map((plan) => (
                            <div
                                key={plan.name}
                                className={`card p-6 md:p-8 relative ${plan.featured
                                        ? "ring-2 ring-accent border-accent"
                                        : ""
                                    }`}
                            >
                                {plan.featured && (
                                    <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                                        <span className="badge badge-pro px-4 py-1">Most Popular</span>
                                    </div>
                                )}
                                <div className="flex items-center gap-3 mb-3">
                                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${plan.featured ? "bg-accent/10" : "bg-primary/5"
                                        }`}>
                                        <plan.icon size={22} className={plan.featured ? "text-accent" : "text-primary"} />
                                    </div>
                                    <h2 className="text-xl font-bold text-gray-900">{plan.name}</h2>
                                </div>

                                {plan.price !== null ? (
                                    <div className="mb-4">
                                        <span className="text-3xl font-bold text-gray-900">{plan.price}</span>
                                        <span className="text-gray-400 ml-1">/{plan.period}</span>
                                    </div>
                                ) : (
                                    <div className="mb-4 space-y-2">
                                        {plan.tiers?.map((tier) => (
                                            <div key={tier.label} className="flex items-center justify-between bg-surface rounded-lg px-4 py-2">
                                                <span className="text-sm text-gray-600">{tier.label}</span>
                                                <div className="flex items-center gap-2">
                                                    <span className="font-bold text-gray-900">{tier.price}</span>
                                                    <span className="text-xs text-gray-400">{tier.period}</span>
                                                    {tier.badge && <span className="badge badge-success text-[10px]">{tier.badge}</span>}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}

                                <p className="text-sm text-gray-500 mb-6">{plan.description}</p>

                                <ul className="space-y-3 mb-6">
                                    {plan.features.map((f) => (
                                        <li key={f.text} className="flex items-center gap-2 text-sm">
                                            {f.included ? (
                                                <CheckCircle2 size={16} className="text-secondary shrink-0" />
                                            ) : (
                                                <X size={16} className="text-gray-300 shrink-0" />
                                            )}
                                            <span className={f.included ? "text-gray-700" : "text-gray-400"}>
                                                {f.text}
                                            </span>
                                        </li>
                                    ))}
                                </ul>

                                {plan.featured ? (
                                    <button className="btn-accent w-full">
                                        <Crown size={16} /> Upgrade to Pro
                                    </button>
                                ) : (
                                    <button className="btn-secondary w-full">Current Plan</button>
                                )}
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* ROI Calculator */}
            <section className="section-padding bg-surface">
                <div className="container-custom text-center max-w-2xl mx-auto">
                    <h2 className="text-2xl font-bold text-gray-900 mb-3">
                        Pro Plan Pays for Itself
                    </h2>
                    <p className="text-gray-500 mb-8">
                        If your business spends ₹50,000/month on facility supplies, the 5% Pro
                        discount saves you ₹2,500/month — that&apos;s ₹30,000/year, more than
                        double the annual plan cost.
                    </p>
                    <div className="grid sm:grid-cols-3 gap-4">
                        <div className="bg-white rounded-xl p-5 border border-border-custom">
                            <p className="text-2xl font-bold text-primary">₹2,500</p>
                            <p className="text-sm text-gray-500">Monthly Savings</p>
                        </div>
                        <div className="bg-white rounded-xl p-5 border border-border-custom">
                            <p className="text-2xl font-bold text-secondary">₹30,000</p>
                            <p className="text-sm text-gray-500">Annual Savings</p>
                        </div>
                        <div className="bg-white rounded-xl p-5 border border-border-custom">
                            <p className="text-2xl font-bold text-accent">2× ROI</p>
                            <p className="text-sm text-gray-500">Return on Investment</p>
                        </div>
                    </div>
                </div>
            </section>

            {/* FAQ */}
            <section className="section-padding">
                <div className="container-custom max-w-2xl mx-auto">
                    <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">
                        Frequently Asked Questions
                    </h2>
                    <div className="space-y-4">
                        {[
                            {
                                q: "Can I cancel my Pro plan anytime?",
                                a: "Yes, you can cancel at any time. Your Pro benefits will continue until the end of your current billing cycle.",
                            },
                            {
                                q: "How is the 5% discount applied?",
                                a: "The 5% discount is automatically applied to every order at checkout. It stacks with bulk pricing tiers for maximum savings.",
                            },
                            {
                                q: "What are the 60-day credit terms?",
                                a: "Pro members get 60 days to pay instead of the standard 45 days. A Razorpay payment link is sent for easy payment.",
                            },
                            {
                                q: "Is there a minimum commitment?",
                                a: "No minimum commitment. Choose monthly for flexibility or annual for maximum savings (38% off).",
                            },
                        ].map((faq) => (
                            <div key={faq.q} className="card p-5">
                                <h3 className="font-semibold text-gray-900 text-sm mb-2">{faq.q}</h3>
                                <p className="text-sm text-gray-500 leading-relaxed">{faq.a}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="section-padding bg-primary">
                <div className="container-custom text-center max-w-2xl mx-auto">
                    <h2 className="text-2xl font-bold text-white mb-3">
                        Ready to Save on Every Order?
                    </h2>
                    <p className="text-white/70 mb-6">
                        Join hundreds of businesses already saving with PrimeServe Pro.
                    </p>
                    <button className="btn-accent text-base px-8">
                        <Star size={18} /> Start Pro Plan Today <ArrowRight size={18} />
                    </button>
                </div>
            </section>
        </>
    );
}
