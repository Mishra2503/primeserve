"use client";

import { useState } from "react";
import Link from "next/link";
import {
    ChevronRight,
    CheckCircle2,
    CreditCard,
    Truck,
    MapPin,
    ClipboardList,
    Shield,
} from "lucide-react";
import { sampleAddresses, products } from "@/lib/mock-data";
import { formatPrice } from "@/lib/utils";

const steps = [
    { id: 1, label: "Shipping", icon: MapPin },
    { id: 2, label: "Delivery", icon: Truck },
    { id: 3, label: "Payment", icon: CreditCard },
    { id: 4, label: "Review", icon: ClipboardList },
];

export default function CheckoutPage() {
    const [step, setStep] = useState(1);
    const [selectedAddress, setSelectedAddress] = useState(sampleAddresses[0].id);
    const [deliveryMethod, setDeliveryMethod] = useState("standard");
    const [paymentMethod, setPaymentMethod] = useState("razorpay");

    const subtotal = 2490000;
    const gst = Math.round(subtotal * 0.18);
    const shipping = deliveryMethod === "express" ? 19900 : 0;
    const total = subtotal + gst + shipping;

    return (
        <>
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary">Home</Link>
                        <ChevronRight size={14} />
                        <Link href="/cart" className="hover:text-primary">Cart</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">Checkout</span>
                    </nav>
                </div>
            </div>

            <div className="container-custom py-6 md:py-10">
                {/* Step Indicator */}
                <div className="flex items-center justify-center gap-0 mb-10 max-w-2xl mx-auto">
                    {steps.map((s, i) => (
                        <div key={s.id} className="flex items-center flex-1 last:flex-initial">
                            <button
                                onClick={() => setStep(s.id)}
                                className={`flex flex-col items-center gap-1.5 ${step >= s.id ? "text-primary" : "text-gray-300"
                                    }`}
                            >
                                <div
                                    className={`w-10 h-10 rounded-full flex items-center justify-center transition-colors ${step > s.id
                                            ? "bg-secondary text-white"
                                            : step === s.id
                                                ? "bg-primary text-white"
                                                : "bg-gray-100 text-gray-400"
                                        }`}
                                >
                                    {step > s.id ? <CheckCircle2 size={20} /> : <s.icon size={18} />}
                                </div>
                                <span className="text-xs font-medium hidden sm:block">{s.label}</span>
                            </button>
                            {i < steps.length - 1 && (
                                <div className={`flex-1 h-0.5 mx-2 rounded ${step > s.id ? "bg-secondary" : "bg-gray-200"}`} />
                            )}
                        </div>
                    ))}
                </div>

                <div className="grid lg:grid-cols-3 gap-8">
                    {/* Form */}
                    <div className="lg:col-span-2">
                        {/* Step 1: Shipping */}
                        {step === 1 && (
                            <div>
                                <h2 className="text-lg font-semibold text-gray-900 mb-4">Select Shipping Address</h2>
                                <div className="space-y-3">
                                    {sampleAddresses.map((addr) => (
                                        <button
                                            key={addr.id}
                                            onClick={() => setSelectedAddress(addr.id)}
                                            className={`w-full text-left card p-4 transition-all ${selectedAddress === addr.id
                                                    ? "ring-2 ring-primary border-primary"
                                                    : ""
                                                }`}
                                        >
                                            <div className="flex items-start justify-between">
                                                <div>
                                                    <div className="flex items-center gap-2 mb-1">
                                                        <span className="text-sm font-semibold text-gray-900">{addr.label}</span>
                                                        {addr.isDefault && <span className="badge badge-info text-[10px]">Default</span>}
                                                    </div>
                                                    <p className="text-sm text-gray-600">{addr.companyName}</p>
                                                    <p className="text-sm text-gray-500">{addr.contactPerson}</p>
                                                    <p className="text-sm text-gray-500">{addr.street}, {addr.city}, {addr.state} — {addr.pincode}</p>
                                                    <p className="text-sm text-gray-400 mt-1">{addr.phone}</p>
                                                </div>
                                                <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${selectedAddress === addr.id ? "border-primary" : "border-gray-300"
                                                    }`}>
                                                    {selectedAddress === addr.id && <div className="w-2.5 h-2.5 rounded-full bg-primary" />}
                                                </div>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                                <button className="btn-secondary mt-4 text-xs">+ Add New Address</button>
                                <div className="flex justify-end mt-6">
                                    <button onClick={() => setStep(2)} className="btn-primary">
                                        Continue to Delivery
                                    </button>
                                </div>
                            </div>
                        )}

                        {/* Step 2: Delivery */}
                        {step === 2 && (
                            <div>
                                <h2 className="text-lg font-semibold text-gray-900 mb-4">Delivery Method</h2>
                                <div className="space-y-3">
                                    {[
                                        {
                                            id: "standard",
                                            title: "Standard Delivery",
                                            desc: "3–5 business days • Free on orders ₹5,000+",
                                            price: "FREE",
                                        },
                                        {
                                            id: "express",
                                            title: "Express Delivery",
                                            desc: "1–2 business days • Priority processing",
                                            price: "₹199",
                                        },
                                    ].map((method) => (
                                        <button
                                            key={method.id}
                                            onClick={() => setDeliveryMethod(method.id)}
                                            className={`w-full text-left card p-4 flex justify-between items-center ${deliveryMethod === method.id ? "ring-2 ring-primary border-primary" : ""
                                                }`}
                                        >
                                            <div className="flex items-center gap-3">
                                                <Truck size={20} className={deliveryMethod === method.id ? "text-primary" : "text-gray-400"} />
                                                <div>
                                                    <p className="text-sm font-semibold text-gray-900">{method.title}</p>
                                                    <p className="text-xs text-gray-500">{method.desc}</p>
                                                </div>
                                            </div>
                                            <span className={`text-sm font-bold ${method.price === "FREE" ? "text-secondary" : "text-gray-900"}`}>
                                                {method.price}
                                            </span>
                                        </button>
                                    ))}
                                </div>
                                <div className="flex justify-between mt-6">
                                    <button onClick={() => setStep(1)} className="btn-secondary">Back</button>
                                    <button onClick={() => setStep(3)} className="btn-primary">Continue to Payment</button>
                                </div>
                            </div>
                        )}

                        {/* Step 3: Payment */}
                        {step === 3 && (
                            <div>
                                <h2 className="text-lg font-semibold text-gray-900 mb-4">Payment Method</h2>
                                <div className="space-y-3">
                                    {[
                                        { id: "razorpay", title: "Pay Now (Razorpay)", desc: "Card, UPI, Net Banking, Wallet", icon: CreditCard },
                                        { id: "credit", title: "Credit Terms (45 Days)", desc: "Buy now, pay within 45 days. Subject to credit approval.", icon: Shield },
                                    ].map((method) => (
                                        <button
                                            key={method.id}
                                            onClick={() => setPaymentMethod(method.id)}
                                            className={`w-full text-left card p-4 flex items-center gap-3 ${paymentMethod === method.id ? "ring-2 ring-primary border-primary" : ""
                                                }`}
                                        >
                                            <method.icon size={20} className={paymentMethod === method.id ? "text-primary" : "text-gray-400"} />
                                            <div>
                                                <p className="text-sm font-semibold text-gray-900">{method.title}</p>
                                                <p className="text-xs text-gray-500">{method.desc}</p>
                                            </div>
                                        </button>
                                    ))}
                                </div>
                                <div className="flex justify-between mt-6">
                                    <button onClick={() => setStep(2)} className="btn-secondary">Back</button>
                                    <button onClick={() => setStep(4)} className="btn-primary">Review Order</button>
                                </div>
                            </div>
                        )}

                        {/* Step 4: Review */}
                        {step === 4 && (
                            <div>
                                <h2 className="text-lg font-semibold text-gray-900 mb-4">Review Your Order</h2>
                                <div className="space-y-4">
                                    <div className="card p-4">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-2">Shipping Address</h3>
                                        {(() => {
                                            const addr = sampleAddresses.find((a) => a.id === selectedAddress)!;
                                            return (
                                                <p className="text-sm text-gray-500">
                                                    {addr.companyName}, {addr.street}, {addr.city}, {addr.state} — {addr.pincode}
                                                </p>
                                            );
                                        })()}
                                    </div>
                                    <div className="card p-4">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-2">Delivery</h3>
                                        <p className="text-sm text-gray-500">
                                            {deliveryMethod === "express" ? "Express Delivery (1–2 days)" : "Standard Delivery (3–5 days)"}
                                        </p>
                                    </div>
                                    <div className="card p-4">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-2">Payment</h3>
                                        <p className="text-sm text-gray-500">
                                            {paymentMethod === "credit" ? "Credit Terms (45 Days)" : "Pay Now via Razorpay"}
                                        </p>
                                    </div>
                                    <div className="card p-4">
                                        <h3 className="text-sm font-semibold text-gray-700 mb-3">Order Items</h3>
                                        <div className="space-y-2">
                                            {[products[0], products[4], products[7]].map((p) => (
                                                <div key={p.id} className="flex justify-between text-sm">
                                                    <span className="text-gray-600">{p.name} × 10</span>
                                                    <span className="font-medium">{formatPrice(p.basePrice * 10)}</span>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                                <div className="flex justify-between mt-6">
                                    <button onClick={() => setStep(3)} className="btn-secondary">Back</button>
                                    <button className="btn-accent text-base px-8">
                                        <Shield size={18} /> Place Order — {formatPrice(total)}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Order Summary Sidebar */}
                    <div className="lg:col-span-1">
                        <div className="card p-6 lg:sticky lg:top-32">
                            <h3 className="font-semibold text-gray-900 mb-4">Order Summary</h3>
                            <div className="space-y-3 text-sm">
                                <div className="flex justify-between">
                                    <span className="text-gray-500">Subtotal (3 items)</span>
                                    <span className="font-medium">{formatPrice(subtotal)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-gray-500">GST (18%)</span>
                                    <span>{formatPrice(gst)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-gray-500">Shipping</span>
                                    <span className={shipping === 0 ? "text-secondary font-medium" : ""}>
                                        {shipping === 0 ? "FREE" : formatPrice(shipping)}
                                    </span>
                                </div>
                                <div className="border-t border-border-custom pt-3 flex justify-between">
                                    <span className="font-semibold">Total</span>
                                    <span className="text-lg font-bold text-primary">{formatPrice(total)}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
