"use client";

import { useState } from "react";
import Link from "next/link";
import {
    ChevronRight,
    Phone,
    Mail,
    MapPin,
    Clock,
    Send,
    MessageSquare,
} from "lucide-react";

export default function ContactPage() {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        company: "",
        phone: "",
        subject: "",
        message: "",
    });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    return (
        <>
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary">Home</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">Contact Us</span>
                    </nav>
                </div>
            </div>

            <section className="section-padding">
                <div className="container-custom">
                    <div className="text-center max-w-2xl mx-auto mb-12">
                        <h1 className="text-3xl font-bold text-gray-900 mb-3">Get in Touch</h1>
                        <p className="text-gray-500">
                            Have questions about our products, pricing, or credit terms? Our team is
                            ready to help you find the right solution.
                        </p>
                    </div>

                    <div className="grid lg:grid-cols-3 gap-8">
                        {/* Contact Info */}
                        <div className="space-y-6">
                            {[
                                {
                                    icon: Phone,
                                    title: "Call Us",
                                    primary: "+91 98765 43210",
                                    secondary: "+91 98765 43211 (Bulk Orders)",
                                },
                                {
                                    icon: Mail,
                                    title: "Email Us",
                                    primary: "orders@primeserve.com",
                                    secondary: "support@primeserve.com",
                                },
                                {
                                    icon: MapPin,
                                    title: "Visit Us",
                                    primary: "Tower A, Business Park",
                                    secondary: "Sector 62, Noida, UP 201309",
                                },
                                {
                                    icon: Clock,
                                    title: "Business Hours",
                                    primary: "Mon – Sat: 9:00 AM – 7:00 PM",
                                    secondary: "Sun: Closed",
                                },
                            ].map((info) => (
                                <div key={info.title} className="flex gap-4">
                                    <div className="w-12 h-12 rounded-xl bg-primary/5 flex items-center justify-center shrink-0">
                                        <info.icon size={22} className="text-primary" />
                                    </div>
                                    <div>
                                        <h3 className="font-semibold text-gray-900 text-sm">{info.title}</h3>
                                        <p className="text-sm text-gray-600">{info.primary}</p>
                                        <p className="text-sm text-gray-400">{info.secondary}</p>
                                    </div>
                                </div>
                            ))}

                            {/* WhatsApp CTA */}
                            <div className="bg-secondary/5 rounded-xl p-5 mt-4">
                                <div className="flex items-center gap-3 mb-2">
                                    <MessageSquare size={20} className="text-secondary" />
                                    <h3 className="font-semibold text-gray-900 text-sm">WhatsApp Support</h3>
                                </div>
                                <p className="text-sm text-gray-500 mb-3">
                                    Chat with us on WhatsApp for quick queries and order updates.
                                </p>
                                <button className="btn-primary bg-secondary hover:bg-secondary-light text-sm h-9">
                                    Open WhatsApp
                                </button>
                            </div>
                        </div>

                        {/* Contact Form */}
                        <div className="lg:col-span-2">
                            <div className="card p-6 md:p-8">
                                <h2 className="font-semibold text-gray-900 mb-6">Send us a Message</h2>
                                <form className="space-y-4">
                                    <div className="grid sm:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                                            <input
                                                type="text" name="name" value={formData.name} onChange={handleChange}
                                                className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                                                placeholder="Rajesh Kumar"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                                            <input
                                                type="email" name="email" value={formData.email} onChange={handleChange}
                                                className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                                                placeholder="rajesh@company.com"
                                            />
                                        </div>
                                    </div>
                                    <div className="grid sm:grid-cols-2 gap-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                                            <input
                                                type="text" name="company" value={formData.company} onChange={handleChange}
                                                className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                                                placeholder="Your Company Pvt Ltd"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Phone Number</label>
                                            <input
                                                type="tel" name="phone" value={formData.phone} onChange={handleChange}
                                                className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary"
                                                placeholder="+91 98765 43210"
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
                                        <select
                                            name="subject" value={formData.subject} onChange={handleChange}
                                            className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary bg-white"
                                        >
                                            <option value="">Select a topic</option>
                                            <option value="bulk">Bulk Order Inquiry</option>
                                            <option value="credit">Credit Terms Application</option>
                                            <option value="pro">Pro Plan Questions</option>
                                            <option value="support">Product Support</option>
                                            <option value="partnership">Partnership Opportunity</option>
                                            <option value="other">Other</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Message *</label>
                                        <textarea
                                            name="message" value={formData.message} onChange={handleChange} rows={5}
                                            className="w-full px-4 py-3 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary resize-none"
                                            placeholder="Tell us about your requirements..."
                                        />
                                    </div>
                                    <button type="button" className="btn-primary">
                                        <Send size={16} /> Send Message
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </>
    );
}
