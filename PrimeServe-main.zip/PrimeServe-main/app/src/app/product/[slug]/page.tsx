"use client";

import { useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import {
    ChevronRight,
    Star,
    ShoppingCart,
    Heart,
    Minus,
    Plus,
    Truck,
    Shield,
    RotateCcw,
    Share2,
    CheckCircle2,
} from "lucide-react";
import { getProductBySlug, getFeaturedProducts, reviews } from "@/lib/mock-data";
import { formatPrice } from "@/lib/utils";
import ProductCard from "@/components/product/product-card";

export default function ProductDetailPage() {
    const params = useParams();
    const slug = params.slug as string;
    const product = getProductBySlug(slug);
    const [quantity, setQuantity] = useState(1);
    const [activeImage, setActiveImage] = useState(0);
    const [activeTab, setActiveTab] = useState("overview");

    // Fallback for unknown slugs
    if (!product) {
        const fallback = getFeaturedProducts()[0];
        if (!fallback) return <div className="container-custom py-20 text-center text-gray-500">Product not found.</div>;
        return <ProductDetailContent product={fallback} />;
    }

    return <ProductDetailContent product={product} />;
}

function ProductDetailContent({ product }: { product: ReturnType<typeof getProductBySlug> }) {
    const [quantity, setQuantity] = useState(product!.minOrderQty);
    const [activeImage, setActiveImage] = useState(0);
    const [activeTab, setActiveTab] = useState("overview");

    if (!product) return null;

    const currentTier = product.pricingTiers.find(
        (t) => quantity >= t.minQuantity && (t.maxQuantity === null || quantity <= t.maxQuantity)
    );
    const unitPrice = currentTier?.pricePerUnit || product.basePrice;
    const lineTotal = unitPrice * quantity;
    const crossSellProducts = getFeaturedProducts().filter((p) => p.id !== product.id).slice(0, 4);

    const tabs = [
        { id: "overview", label: "Overview" },
        { id: "specs", label: "Specifications" },
        { id: "usage", label: "Usage Guide" },
        { id: "shipping", label: "Shipping" },
        { id: "reviews", label: `Reviews (${product.reviewCount})` },
    ];

    return (
        <>
            {/* Breadcrumbs */}
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500 flex-wrap">
                        <Link href="/" className="hover:text-primary transition-colors">Home</Link>
                        <ChevronRight size={14} />
                        <Link href={`/category/${product.categorySlug}`} className="hover:text-primary transition-colors">{product.categoryName}</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium truncate max-w-xs">{product.name}</span>
                    </nav>
                </div>
            </div>

            <div className="container-custom py-6 md:py-10">
                <div className="grid lg:grid-cols-2 gap-8 lg:gap-12">
                    {/* Image Gallery */}
                    <div>
                        <div className="aspect-square bg-gray-50 rounded-xl overflow-hidden mb-3">
                            <img
                                src={product.images[activeImage]}
                                alt={product.name}
                                className="w-full h-full object-cover"
                            />
                        </div>
                        {product.images.length > 1 && (
                            <div className="flex gap-2">
                                {product.images.map((img, i) => (
                                    <button
                                        key={i}
                                        onClick={() => setActiveImage(i)}
                                        className={`w-16 h-16 rounded-lg overflow-hidden border-2 transition-colors ${i === activeImage ? "border-primary" : "border-transparent"
                                            }`}
                                    >
                                        <img src={img} alt="" className="w-full h-full object-cover" />
                                    </button>
                                ))}
                            </div>
                        )}
                    </div>

                    {/* Product Info */}
                    <div>
                        <div className="flex items-center gap-2 mb-2">
                            <span className="text-xs text-gray-400">SKU: {product.sku}</span>
                            <span className="text-xs text-gray-300">|</span>
                            <span className="text-xs text-gray-400">{product.brand}</span>
                        </div>
                        <h1 className="text-xl md:text-2xl font-bold text-gray-900 mb-3">
                            {product.name}
                        </h1>

                        {/* Rating */}
                        <div className="flex items-center gap-2 mb-4">
                            <div className="flex">
                                {Array.from({ length: 5 }).map((_, i) => (
                                    <Star
                                        key={i}
                                        size={16}
                                        className={
                                            i < Math.floor(product.rating) ? "fill-accent text-accent" : "text-gray-200"
                                        }
                                    />
                                ))}
                            </div>
                            <span className="text-sm font-medium text-gray-700">{product.rating}</span>
                            <span className="text-sm text-gray-400">({product.reviewCount} reviews)</span>
                        </div>

                        <p className="text-gray-600 text-sm leading-relaxed mb-6">{product.shortDescription}</p>

                        {/* Price */}
                        <div className="bg-surface rounded-xl p-5 mb-6">
                            <div className="flex items-baseline gap-3 mb-1">
                                <span className="text-2xl font-bold text-primary">{formatPrice(unitPrice)}</span>
                                <span className="text-sm text-gray-400">/{product.unit}</span>
                            </div>
                            {unitPrice < product.basePrice && (
                                <p className="text-sm text-secondary font-medium flex items-center gap-1">
                                    <CheckCircle2 size={14} />
                                    Bulk discount applied — you save {formatPrice(product.basePrice - unitPrice)}/{product.unit}
                                </p>
                            )}
                        </div>

                        {/* Bulk Pricing Tiers */}
                        {product.pricingTiers.length > 0 && (
                            <div className="mb-6">
                                <h3 className="text-sm font-semibold text-gray-900 mb-3">Bulk Pricing</h3>
                                <div className="grid grid-cols-3 gap-2">
                                    {product.pricingTiers.map((tier, i) => (
                                        <button
                                            key={i}
                                            onClick={() => setQuantity(tier.minQuantity)}
                                            className={`p-3 rounded-lg border text-center transition-all ${currentTier === tier
                                                    ? "border-primary bg-primary/5 ring-1 ring-primary"
                                                    : "border-border-custom hover:border-primary/30"
                                                }`}
                                        >
                                            <p className="text-xs text-gray-500">
                                                {tier.minQuantity}–{tier.maxQuantity ?? "∞"} {product.unit}s
                                            </p>
                                            <p className="text-sm font-bold text-gray-900">{formatPrice(tier.pricePerUnit)}</p>
                                            {i > 0 && (
                                                <p className="text-xs text-secondary font-medium">
                                                    Save {Math.round(((product.basePrice - tier.pricePerUnit) / product.basePrice) * 100)}%
                                                </p>
                                            )}
                                        </button>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Quantity + Add to Cart */}
                        <div className="flex flex-col sm:flex-row gap-3 mb-6">
                            <div className="flex items-center border border-border-custom rounded-lg overflow-hidden">
                                <button
                                    onClick={() => setQuantity(Math.max(product.minOrderQty, quantity - 1))}
                                    className="p-3 hover:bg-surface transition-colors"
                                >
                                    <Minus size={16} />
                                </button>
                                <input
                                    type="number"
                                    value={quantity}
                                    onChange={(e) => setQuantity(Math.max(product.minOrderQty, parseInt(e.target.value) || 1))}
                                    className="w-16 text-center text-sm font-medium border-x border-border-custom py-3 focus:outline-none"
                                    min={product.minOrderQty}
                                />
                                <button
                                    onClick={() => setQuantity(quantity + 1)}
                                    className="p-3 hover:bg-surface transition-colors"
                                >
                                    <Plus size={16} />
                                </button>
                            </div>
                            <button className="btn-primary flex-1 h-12">
                                <ShoppingCart size={18} />
                                Add to Cart — {formatPrice(lineTotal)}
                            </button>
                            <button className="btn-secondary h-12 px-4">
                                <Heart size={18} />
                            </button>
                        </div>

                        {/* Stock */}
                        <div className="flex items-center gap-2 text-sm mb-6">
                            {product.stock > 20 ? (
                                <span className="badge badge-success">In Stock ({product.stock} available)</span>
                            ) : product.stock > 0 ? (
                                <span className="badge badge-warning">Low Stock ({product.stock} left)</span>
                            ) : (
                                <span className="badge badge-error">Out of Stock</span>
                            )}
                        </div>

                        {/* Trust badges */}
                        <div className="grid grid-cols-3 gap-3 pt-6 border-t border-border-custom">
                            {[
                                { icon: Truck, title: "Free Delivery", sub: "Orders ₹5,000+" },
                                { icon: Shield, title: "GST Invoice", sub: "Zoho powered" },
                                { icon: RotateCcw, title: "Easy Returns", sub: "7-day policy" },
                            ].map(({ icon: Icon, title, sub }) => (
                                <div key={title} className="text-center">
                                    <Icon size={20} className="mx-auto text-primary mb-1" />
                                    <p className="text-xs font-semibold text-gray-900">{title}</p>
                                    <p className="text-xs text-gray-400">{sub}</p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>

                {/* Tabs */}
                <div className="mt-12">
                    <div className="border-b border-border-custom flex gap-0 overflow-x-auto">
                        {tabs.map((tab) => (
                            <button
                                key={tab.id}
                                onClick={() => setActiveTab(tab.id)}
                                className={`px-4 py-3 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${activeTab === tab.id
                                        ? "border-primary text-primary"
                                        : "border-transparent text-gray-500 hover:text-gray-700"
                                    }`}
                            >
                                {tab.label}
                            </button>
                        ))}
                    </div>
                    <div className="py-8">
                        {activeTab === "overview" && (
                            <div className="prose prose-sm max-w-none text-gray-600 leading-relaxed">
                                <p>{product.description}</p>
                            </div>
                        )}
                        {activeTab === "specs" && (
                            <div className="max-w-lg">
                                <table className="w-full text-sm">
                                    <tbody>
                                        {Object.entries(product.specs).map(([key, value]) => (
                                            <tr key={key} className="border-b border-border-custom">
                                                <td className="py-3 text-gray-500 font-medium pr-4">{key}</td>
                                                <td className="py-3 text-gray-900">{value}</td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        )}
                        {activeTab === "usage" && (
                            <div className="prose prose-sm max-w-none text-gray-600">
                                {product.usageInstructions ? (
                                    <p>{product.usageInstructions}</p>
                                ) : (
                                    <p>No specific usage instructions provided. Please refer to the product packaging for detailed usage guidelines.</p>
                                )}
                            </div>
                        )}
                        {activeTab === "shipping" && (
                            <div className="prose prose-sm max-w-none text-gray-600 space-y-3">
                                <p><strong>Delivery:</strong> Standard delivery within 3–5 business days. Express delivery available for select locations.</p>
                                <p><strong>Free Shipping:</strong> Free delivery on all orders above ₹5,000.</p>
                                <p><strong>Returns:</strong> 7-day easy return policy. Product must be unused and in original packaging.</p>
                                <p><strong>GST Invoice:</strong> GST-compliant invoice generated via Zoho Books and sent automatically on order confirmation.</p>
                            </div>
                        )}
                        {activeTab === "reviews" && (
                            <div className="space-y-6 max-w-2xl">
                                {reviews.map((r) => (
                                    <div key={r.id} className="border-b border-border-custom pb-6">
                                        <div className="flex items-center gap-2 mb-2">
                                            <div className="flex">
                                                {Array.from({ length: 5 }).map((_, i) => (
                                                    <Star key={i} size={14} className={i < r.rating ? "fill-accent text-accent" : "text-gray-200"} />
                                                ))}
                                            </div>
                                            {r.isVerified && <span className="badge badge-success text-[10px]">Verified Purchase</span>}
                                        </div>
                                        <h4 className="font-semibold text-sm text-gray-900 mb-1">{r.title}</h4>
                                        <p className="text-sm text-gray-600 mb-2">{r.body}</p>
                                        <p className="text-xs text-gray-400">{r.userName} · {r.companyName} · {r.date}</p>
                                    </div>
                                ))}
                            </div>
                        )}
                    </div>
                </div>

                {/* Cross-sell */}
                {crossSellProducts.length > 0 && (
                    <div className="mt-8">
                        <h2 className="text-xl font-bold text-gray-900 mb-6">You May Also Like</h2>
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-5">
                            {crossSellProducts.map((p) => (
                                <ProductCard key={p.id} product={p} />
                            ))}
                        </div>
                    </div>
                )}
            </div>
        </>
    );
}
