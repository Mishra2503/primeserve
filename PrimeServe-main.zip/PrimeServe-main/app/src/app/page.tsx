import Link from "next/link";
import {
  ArrowRight,
  Truck,
  CreditCard,
  Shield,
  Headphones,
  Star,
  CheckCircle2,
  ChevronRight,
  Building2,
  Award,
  Clock,
  Brush,
  FlaskConical,
  Pencil,
  Coffee,
} from "lucide-react";
import { categories, getFeaturedProducts, testimonials } from "@/lib/mock-data";
import ProductCard from "@/components/product/product-card";

const iconMap: Record<string, React.ElementType> = {
  Brush, FlaskConical, Pencil, Coffee,
};

export default function HomePage() {
  const featuredProducts = getFeaturedProducts();

  return (
    <>
      {/* ───── Hero ───── */}
      <section className="relative bg-gradient-to-br from-primary via-primary-dark to-[#0F172A] overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 right-20 w-96 h-96 bg-secondary rounded-full blur-3xl" />
          <div className="absolute -bottom-20 -left-20 w-80 h-80 bg-accent rounded-full blur-3xl" />
        </div>
        <div className="container-custom relative z-10 py-16 md:py-24 lg:py-28">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-1.5 mb-6 text-sm text-white/90">
              <Star size={14} className="text-accent" />
              Trusted by 1,000+ businesses across India
            </div>
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-4">
              Your One-Stop B2B Marketplace for{" "}
              <span className="text-secondary-light">Facility Supplies</span>
            </h1>
            <p className="text-base md:text-lg text-white/80 mb-8 leading-relaxed max-w-xl">
              Premium housekeeping materials, cleaning chemicals, office stationery, and
              pantry items — all with bulk pricing, 45-day credit terms, and dedicated
              support.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Link href="/category/housekeeping-materials" className="btn-accent">
                Browse Products <ArrowRight size={16} />
              </Link>
              <Link href="/pro-plan" className="btn-secondary !border-white/30 !text-white hover:!bg-white/10">
                Explore Pro Plan
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 mt-10 text-sm text-white/70">
              {[
                { icon: Truck, text: "Free Delivery on ₹5,000+" },
                { icon: CreditCard, text: "45-Day Credit Terms" },
                { icon: Shield, text: "GST Invoicing" },
              ].map(({ icon: Icon, text }) => (
                <span key={text} className="flex items-center gap-2">
                  <Icon size={16} className="text-secondary-light" /> {text}
                </span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ───── Categories ───── */}
      <section className="section-padding bg-surface">
        <div className="container-custom">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
              Shop by Category
            </h2>
            <p className="text-gray-500 max-w-lg mx-auto">
              Everything your facility needs, organized for quick ordering.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {categories.map((cat) => {
              const Icon = iconMap[cat.icon] || Brush;
              return (
                <Link
                  key={cat.slug}
                  href={`/category/${cat.slug}`}
                  className="card group p-5 text-center"
                >
                  <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-primary/5 flex items-center justify-center group-hover:bg-primary/10 transition-colors">
                    <Icon size={28} className="text-primary" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">{cat.name}</h3>
                  <p className="text-xs text-gray-500 mb-3 line-clamp-2">
                    {cat.description}
                  </p>
                  <span className="inline-flex items-center gap-1 text-xs font-semibold text-primary">
                    {cat.productCount} Products <ChevronRight size={14} />
                  </span>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* ───── Key Benefits ───── */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
              Why Businesses Choose PrimeServe
            </h2>
            <p className="text-gray-500 max-w-lg mx-auto">
              Built for B2B procurement teams who need reliability, pricing, and speed.
            </p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                icon: CreditCard,
                title: "45-Day Credit Terms",
                desc: "Buy now, pay later. Approved businesses get up to ₹10 lakh credit line with flexible payment terms.",
                color: "text-primary",
                bg: "bg-primary/5",
              },
              {
                icon: Truck,
                title: "Free & Fast Delivery",
                desc: "Free delivery on orders above ₹5,000. Same-day dispatch for in-stock items.",
                color: "text-secondary",
                bg: "bg-secondary/5",
              },
              {
                icon: Award,
                title: "Bulk Pricing Tiers",
                desc: "The more you order, the more you save. Automatic tiered pricing on all products.",
                color: "text-accent",
                bg: "bg-accent/5",
              },
              {
                icon: Headphones,
                title: "Dedicated Support",
                desc: "Assigned account manager for Pro customers. Expert support via phone, email, and WhatsApp.",
                color: "text-info",
                bg: "bg-info/5",
              },
            ].map((b) => (
              <div key={b.title} className="text-center p-6">
                <div
                  className={`w-14 h-14 mx-auto mb-4 rounded-xl ${b.bg} flex items-center justify-center`}
                >
                  <b.icon size={28} className={b.color} />
                </div>
                <h3 className="font-semibold text-gray-900 mb-2">{b.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{b.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───── Featured Products ───── */}
      <section className="section-padding bg-surface">
        <div className="container-custom">
          <div className="flex items-end justify-between mb-8">
            <div>
              <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-1">
                Featured Products
              </h2>
              <p className="text-gray-500">Top-selling essentials picked for you.</p>
            </div>
            <Link
              href="/category/housekeeping-materials"
              className="hidden sm:inline-flex items-center gap-1 text-sm font-semibold text-primary hover:underline"
            >
              View All <ArrowRight size={16} />
            </Link>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-5">
            {featuredProducts.slice(0, 8).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
          <div className="text-center mt-8 sm:hidden">
            <Link href="/category/housekeeping-materials" className="btn-secondary">
              View All Products
            </Link>
          </div>
        </div>
      </section>

      {/* ───── Pro Plan Teaser ───── */}
      <section className="section-padding">
        <div className="container-custom">
          <div className="bg-gradient-to-br from-primary via-primary-dark to-[#0F172A] rounded-2xl p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 right-0 w-72 h-72 bg-accent/10 rounded-full blur-3xl" />
            <div className="relative z-10 grid md:grid-cols-2 gap-8 items-center">
              <div>
                <span className="badge badge-pro mb-4">⭐ Pro Plan</span>
                <h2 className="text-2xl md:text-3xl font-bold text-white mb-3">
                  Unlock Premium Benefits
                </h2>
                <p className="text-white/70 mb-6 leading-relaxed">
                  Get 5% off every order, priority support, extended credit terms, and
                  exclusive access to new products.
                </p>
                <Link href="/pro-plan" className="btn-accent">
                  Explore Pro Plan <ArrowRight size={16} />
                </Link>
              </div>
              <div className="space-y-3">
                {[
                  "5% instant discount on all orders",
                  "60-day credit terms (vs 45-day standard)",
                  "Dedicated account manager",
                  "Priority order processing",
                  "Exclusive monthly deals",
                  "Free delivery on all orders",
                ].map((benefit) => (
                  <div key={benefit} className="flex items-center gap-3 text-white/90 text-sm">
                    <CheckCircle2 size={18} className="text-secondary shrink-0" />
                    {benefit}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ───── Testimonials ───── */}
      <section className="section-padding bg-surface">
        <div className="container-custom">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-2">
              Trusted by Leading Companies
            </h2>
            <p className="text-gray-500 max-w-lg mx-auto">
              Hear from facility managers and procurement teams who switched to PrimeServe.
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <div
                key={t.id}
                className="card p-6"
              >
                <div className="flex gap-0.5 mb-4">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} size={16} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-sm text-gray-600 leading-relaxed mb-6 italic">
                  &ldquo;{t.quote}&rdquo;
                </p>
                <div className="flex items-center gap-3 pt-4 border-t border-border-custom">
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Building2 size={18} className="text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-900">{t.author}</p>
                    <p className="text-xs text-gray-500">
                      {t.role}, {t.company}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ───── Stats Strip ───── */}
      <section className="bg-primary py-12">
        <div className="container-custom grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
          {[
            { value: "1,000+", label: "Active Businesses" },
            { value: "15,000+", label: "Products Delivered" },
            { value: "₹2Cr+", label: "Monthly GMV" },
            { value: "98%", label: "On-Time Delivery" },
          ].map((s) => (
            <div key={s.label}>
              <p className="text-2xl md:text-3xl font-bold text-white">{s.value}</p>
              <p className="text-sm text-white/60 mt-1">{s.label}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ───── CTA Banner ───── */}
      <section className="section-padding">
        <div className="container-custom text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-2xl md:text-3xl font-bold text-gray-900 mb-3">
              Ready to Simplify Your Procurement?
            </h2>
            <p className="text-gray-500 mb-8">
              Join 1,000+ businesses saving time and money on facility supplies. Get
              started with your first order today.
            </p>
            <div className="flex flex-col sm:flex-row gap-3 justify-center">
              <Link href="/category/housekeeping-materials" className="btn-primary">
                Start Shopping <ArrowRight size={16} />
              </Link>
              <Link href="/contact" className="btn-secondary">
                <Clock size={16} />
                Schedule a Call
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
