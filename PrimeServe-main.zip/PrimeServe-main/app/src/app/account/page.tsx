"use client";

import { useState } from "react";
import Link from "next/link";
import {
    LayoutDashboard,
    Package,
    CreditCard,
    Heart,
    MapPin,
    User,
    Crown,
    ChevronRight,
    TrendingUp,
    ShoppingCart,
    Clock,
    IndianRupee,
    Eye,
} from "lucide-react";
import { sampleOrders, sampleAddresses } from "@/lib/mock-data";
import { formatPrice } from "@/lib/utils";

const sidebarLinks = [
    { id: "overview", label: "Overview", icon: LayoutDashboard },
    { id: "orders", label: "Order History", icon: Package },
    { id: "credit", label: "Credit Account", icon: CreditCard },
    { id: "favorites", label: "Favorites", icon: Heart },
    { id: "addresses", label: "Addresses", icon: MapPin },
    { id: "profile", label: "Profile", icon: User },
];

export default function AccountPage() {
    const [activeTab, setActiveTab] = useState("overview");

    return (
        <>
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary">Home</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">My Account</span>
                    </nav>
                </div>
            </div>

            <div className="container-custom py-6 md:py-10">
                <div className="flex flex-col md:flex-row gap-6 md:gap-8">
                    {/* Sidebar */}
                    <aside className="md:w-56 shrink-0">
                        <div className="card p-4 mb-4">
                            <div className="flex items-center gap-3">
                                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
                                    <User size={24} className="text-primary" />
                                </div>
                                <div>
                                    <p className="font-semibold text-gray-900 text-sm">Rajesh Kumar</p>
                                    <p className="text-xs text-gray-500">TechCorp Solutions</p>
                                </div>
                            </div>
                        </div>
                        <nav className="space-y-1">
                            {sidebarLinks.map((link) => (
                                <button
                                    key={link.id}
                                    onClick={() => setActiveTab(link.id)}
                                    className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${activeTab === link.id
                                            ? "bg-primary/5 text-primary"
                                            : "text-gray-600 hover:bg-surface hover:text-gray-900"
                                        }`}
                                >
                                    <link.icon size={18} />
                                    {link.label}
                                </button>
                            ))}
                        </nav>
                        <div className="mt-4 p-4 bg-gradient-to-br from-accent/10 to-accent/5 rounded-xl">
                            <div className="flex items-center gap-2 mb-2">
                                <Crown size={16} className="text-accent" />
                                <span className="text-xs font-semibold text-gray-900">Free Account</span>
                            </div>
                            <p className="text-xs text-gray-500 mb-3">Upgrade for 5% off all orders.</p>
                            <Link href="/pro-plan" className="btn-accent h-8 text-xs w-full">
                                Upgrade to Pro
                            </Link>
                        </div>
                    </aside>

                    {/* Content */}
                    <div className="flex-1">
                        {/* Overview */}
                        {activeTab === "overview" && (
                            <div>
                                <h1 className="text-xl font-bold text-gray-900 mb-6">Dashboard Overview</h1>
                                <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
                                    {[
                                        { label: "Total Orders", value: "23", icon: ShoppingCart, color: "text-primary", bg: "bg-primary/5" },
                                        { label: "Total Spent", value: "₹4.2L", icon: IndianRupee, color: "text-secondary", bg: "bg-secondary/5" },
                                        { label: "Available Credit", value: "₹3.5L", icon: CreditCard, color: "text-accent", bg: "bg-accent/5" },
                                        { label: "Pending Orders", value: "2", icon: Clock, color: "text-info", bg: "bg-info/5" },
                                    ].map((stat) => (
                                        <div key={stat.label} className="card p-4">
                                            <div className="flex items-center justify-between mb-3">
                                                <span className="text-xs text-gray-500 font-medium">{stat.label}</span>
                                                <div className={`w-8 h-8 rounded-lg ${stat.bg} flex items-center justify-center`}>
                                                    <stat.icon size={16} className={stat.color} />
                                                </div>
                                            </div>
                                            <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                                        </div>
                                    ))}
                                </div>

                                <h2 className="text-lg font-semibold text-gray-900 mb-4">Recent Orders</h2>
                                <div className="card overflow-hidden">
                                    <div className="overflow-x-auto">
                                        <table className="w-full text-sm">
                                            <thead className="bg-surface">
                                                <tr>
                                                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500">Order</th>
                                                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500">Date</th>
                                                    <th className="text-left px-4 py-3 text-xs font-semibold text-gray-500">Status</th>
                                                    <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500">Total</th>
                                                    <th className="text-right px-4 py-3 text-xs font-semibold text-gray-500"></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {sampleOrders.map((order) => (
                                                    <tr key={order.id} className="border-t border-border-custom">
                                                        <td className="px-4 py-3 font-medium text-gray-900">{order.orderNumber}</td>
                                                        <td className="px-4 py-3 text-gray-500">{order.date}</td>
                                                        <td className="px-4 py-3">
                                                            <span className={`badge ${order.status === "Delivered" ? "badge-success" :
                                                                    order.status === "Shipped" ? "badge-info" :
                                                                        "badge-warning"
                                                                }`}>
                                                                {order.status}
                                                            </span>
                                                        </td>
                                                        <td className="px-4 py-3 text-right font-medium text-gray-900">
                                                            {formatPrice(order.total)}
                                                        </td>
                                                        <td className="px-4 py-3 text-right">
                                                            <button className="text-primary hover:underline text-xs flex items-center gap-1 ml-auto">
                                                                <Eye size={12} /> View
                                                            </button>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Orders */}
                        {activeTab === "orders" && (
                            <div>
                                <h1 className="text-xl font-bold text-gray-900 mb-6">Order History</h1>
                                <div className="space-y-4">
                                    {sampleOrders.map((order) => (
                                        <div key={order.id} className="card p-5">
                                            <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
                                                <div>
                                                    <p className="font-semibold text-gray-900">{order.orderNumber}</p>
                                                    <p className="text-xs text-gray-400">Placed on {order.date}</p>
                                                </div>
                                                <div className="flex items-center gap-3">
                                                    <span className={`badge ${order.status === "Delivered" ? "badge-success" :
                                                            order.status === "Shipped" ? "badge-info" : "badge-warning"
                                                        }`}>{order.status}</span>
                                                    <span className="font-bold text-primary">{formatPrice(order.total)}</span>
                                                </div>
                                            </div>
                                            <div className="space-y-2">
                                                {order.items.map((item, i) => (
                                                    <div key={i} className="flex justify-between text-sm border-t border-border-custom pt-2">
                                                        <span className="text-gray-600">{item.name} × {item.quantity}</span>
                                                        <span className="text-gray-900 font-medium">{formatPrice(item.price)}</span>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Credit */}
                        {activeTab === "credit" && (
                            <div>
                                <h1 className="text-xl font-bold text-gray-900 mb-6">Credit Account</h1>
                                <div className="grid sm:grid-cols-3 gap-4 mb-6">
                                    <div className="card p-5 text-center">
                                        <p className="text-xs text-gray-500 mb-1">Credit Limit</p>
                                        <p className="text-2xl font-bold text-gray-900">₹5,00,000</p>
                                    </div>
                                    <div className="card p-5 text-center">
                                        <p className="text-xs text-gray-500 mb-1">Available Credit</p>
                                        <p className="text-2xl font-bold text-secondary">₹3,50,000</p>
                                    </div>
                                    <div className="card p-5 text-center">
                                        <p className="text-xs text-gray-500 mb-1">Outstanding</p>
                                        <p className="text-2xl font-bold text-accent">₹1,50,000</p>
                                    </div>
                                </div>
                                <div className="card p-5">
                                    <h3 className="font-semibold text-gray-900 mb-1">Credit Status</h3>
                                    <span className="badge badge-success">Approved</span>
                                    <p className="text-sm text-gray-500 mt-3">
                                        Your credit account is active with 45-day payment terms. Upgrade to Pro
                                        for 60-day terms and higher limits.
                                    </p>
                                    <div className="mt-4 w-full bg-gray-100 rounded-full h-3">
                                        <div className="bg-secondary h-3 rounded-full" style={{ width: "70%" }} />
                                    </div>
                                    <p className="text-xs text-gray-400 mt-1">70% available</p>
                                </div>
                            </div>
                        )}

                        {/* Favorites */}
                        {activeTab === "favorites" && (
                            <div>
                                <h1 className="text-xl font-bold text-gray-900 mb-6">Favorites</h1>
                                <p className="text-gray-500 text-sm">Your saved products will appear here. Browse products and click the heart icon to add favorites.</p>
                                <Link href="/category/housekeeping-materials" className="btn-primary mt-4">
                                    Browse Products
                                </Link>
                            </div>
                        )}

                        {/* Addresses */}
                        {activeTab === "addresses" && (
                            <div>
                                <div className="flex items-center justify-between mb-6">
                                    <h1 className="text-xl font-bold text-gray-900">Saved Addresses</h1>
                                    <button className="btn-secondary text-xs">+ Add Address</button>
                                </div>
                                <div className="grid sm:grid-cols-2 gap-4">
                                    {sampleAddresses.map((addr) => (
                                        <div key={addr.id} className="card p-5">
                                            <div className="flex items-center gap-2 mb-2">
                                                <span className="font-semibold text-gray-900 text-sm">{addr.label}</span>
                                                {addr.isDefault && <span className="badge badge-info text-[10px]">Default</span>}
                                            </div>
                                            <p className="text-sm text-gray-600">{addr.companyName}</p>
                                            <p className="text-sm text-gray-500">{addr.contactPerson}</p>
                                            <p className="text-sm text-gray-500">{addr.street}</p>
                                            <p className="text-sm text-gray-500">{addr.city}, {addr.state} — {addr.pincode}</p>
                                            <p className="text-sm text-gray-400 mt-1">{addr.phone}</p>
                                            <div className="flex gap-3 mt-3 pt-3 border-t border-border-custom">
                                                <button className="text-xs text-primary font-medium hover:underline">Edit</button>
                                                <button className="text-xs text-error font-medium hover:underline">Delete</button>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {/* Profile */}
                        {activeTab === "profile" && (
                            <div>
                                <h1 className="text-xl font-bold text-gray-900 mb-6">Profile Settings</h1>
                                <div className="card p-6 max-w-lg">
                                    <div className="space-y-4">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Full Name</label>
                                            <input type="text" defaultValue="Rajesh Kumar" className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                                            <input type="email" defaultValue="rajesh@techcorp.com" className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Company Name</label>
                                            <input type="text" defaultValue="TechCorp Solutions Pvt Ltd" className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">GST Number</label>
                                            <input type="text" defaultValue="07AACCT1234A1Z5" className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                                            <input type="tel" defaultValue="+91 98765 43210" className="w-full h-10 px-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30" />
                                        </div>
                                        <button className="btn-primary mt-2">Save Changes</button>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </>
    );
}
