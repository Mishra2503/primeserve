"use client";

import { useState } from "react";
import Link from "next/link";
import {
    ChevronRight,
    Minus,
    Plus,
    Trash2,
    ShoppingCart,
    ArrowRight,
    Tag,
} from "lucide-react";
import { products } from "@/lib/mock-data";
import { formatPrice } from "@/lib/utils";
import type { CartItem } from "@/types";

// Mock cart data
const initialCart: CartItem[] = [
    { product: products[0], quantity: 10 },
    { product: products[4], quantity: 5 },
    { product: products[7], quantity: 25 },
];

export default function CartPage() {
    const [cart, setCart] = useState<CartItem[]>(initialCart);
    const [promoCode, setPromoCode] = useState("");
    const [promoApplied, setPromoApplied] = useState(false);

    const updateQty = (id: string, delta: number) => {
        setCart((prev) =>
            prev.map((item) =>
                item.product.id === id
                    ? { ...item, quantity: Math.max(item.product.minOrderQty, item.quantity + delta) }
                    : item
            )
        );
    };

    const removeItem = (id: string) => {
        setCart((prev) => prev.filter((item) => item.product.id !== id));
    };

    const getUnitPrice = (item: CartItem) => {
        const tier = item.product.pricingTiers.find(
            (t) => item.quantity >= t.minQuantity && (t.maxQuantity === null || item.quantity <= t.maxQuantity)
        );
        return tier?.pricePerUnit || item.product.basePrice;
    };

    const subtotal = cart.reduce((sum, item) => sum + getUnitPrice(item) * item.quantity, 0);
    const discount = promoApplied ? Math.round(subtotal * 0.05) : 0;
    const gst = Math.round((subtotal - discount) * 0.18);
    const shipping = subtotal >= 500000 ? 0 : 9900;
    const total = subtotal - discount + gst + shipping;

    if (cart.length === 0) {
        return (
            <div className="container-custom py-20 text-center">
                <ShoppingCart size={64} className="mx-auto text-gray-300 mb-4" />
                <h1 className="text-2xl font-bold text-gray-900 mb-2">Your Cart is Empty</h1>
                <p className="text-gray-500 mb-6">Browse our products and add items to your cart.</p>
                <Link href="/category/housekeeping-materials" className="btn-primary">
                    Start Shopping <ArrowRight size={16} />
                </Link>
            </div>
        );
    }

    return (
        <>
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary">Home</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">Shopping Cart</span>
                    </nav>
                </div>
            </div>

            <div className="container-custom py-6 md:py-10">
                <h1 className="text-2xl font-bold text-gray-900 mb-6">
                    Shopping Cart ({cart.length} items)
                </h1>

                <div className="grid lg:grid-cols-3 gap-8">
                    {/* Cart Items */}
                    <div className="lg:col-span-2 space-y-4">
                        {cart.map((item) => {
                            const price = getUnitPrice(item);
                            return (
                                <div key={item.product.id} className="card p-4 flex gap-4">
                                    <img
                                        src={item.product.images[0]}
                                        alt={item.product.name}
                                        className="w-20 h-20 sm:w-24 sm:h-24 object-cover rounded-lg bg-gray-50 shrink-0"
                                    />
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between gap-4">
                                            <div>
                                                <Link
                                                    href={`/product/${item.product.slug}`}
                                                    className="text-sm font-semibold text-gray-900 hover:text-primary transition-colors line-clamp-1"
                                                >
                                                    {item.product.name}
                                                </Link>
                                                <p className="text-xs text-gray-400 mt-0.5">
                                                    {item.product.brand} • SKU: {item.product.sku}
                                                </p>
                                            </div>
                                            <p className="text-sm font-bold text-primary whitespace-nowrap">
                                                {formatPrice(price * item.quantity)}
                                            </p>
                                        </div>

                                        <div className="flex items-center justify-between mt-3">
                                            <div className="flex items-center border border-border-custom rounded-lg overflow-hidden">
                                                <button onClick={() => updateQty(item.product.id, -1)} className="p-2 hover:bg-surface">
                                                    <Minus size={14} />
                                                </button>
                                                <span className="px-3 text-sm font-medium border-x border-border-custom">{item.quantity}</span>
                                                <button onClick={() => updateQty(item.product.id, 1)} className="p-2 hover:bg-surface">
                                                    <Plus size={14} />
                                                </button>
                                            </div>
                                            <div className="flex items-center gap-3">
                                                <span className="text-xs text-gray-400">
                                                    {formatPrice(price)}/{item.product.unit}
                                                </span>
                                                <button
                                                    onClick={() => removeItem(item.product.id)}
                                                    className="text-gray-400 hover:text-error transition-colors p-1"
                                                >
                                                    <Trash2 size={16} />
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    {/* Order Summary */}
                    <div className="lg:col-span-1">
                        <div className="card p-6 lg:sticky lg:top-32">
                            <h2 className="font-semibold text-gray-900 mb-4">Order Summary</h2>

                            {/* Promo Code */}
                            <div className="flex gap-2 mb-5">
                                <div className="relative flex-1">
                                    <Tag size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                                    <input
                                        type="text"
                                        value={promoCode}
                                        onChange={(e) => setPromoCode(e.target.value)}
                                        placeholder="Promo code"
                                        className="w-full h-9 pl-9 pr-3 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                                    />
                                </div>
                                <button
                                    onClick={() => setPromoApplied(promoCode.length > 0)}
                                    className="btn-secondary text-xs h-9 px-4"
                                >
                                    Apply
                                </button>
                            </div>

                            <div className="space-y-3 text-sm">
                                <div className="flex justify-between">
                                    <span className="text-gray-500">Subtotal</span>
                                    <span className="font-medium text-gray-900">{formatPrice(subtotal)}</span>
                                </div>
                                {discount > 0 && (
                                    <div className="flex justify-between text-secondary">
                                        <span>Promo Discount (5%)</span>
                                        <span className="font-medium">-{formatPrice(discount)}</span>
                                    </div>
                                )}
                                <div className="flex justify-between">
                                    <span className="text-gray-500">GST (18%)</span>
                                    <span className="text-gray-900">{formatPrice(gst)}</span>
                                </div>
                                <div className="flex justify-between">
                                    <span className="text-gray-500">Shipping</span>
                                    <span className="text-gray-900">
                                        {shipping === 0 ? (
                                            <span className="text-secondary font-medium">FREE</span>
                                        ) : (
                                            formatPrice(shipping)
                                        )}
                                    </span>
                                </div>
                                <div className="border-t border-border-custom pt-3 flex justify-between">
                                    <span className="font-semibold text-gray-900">Total</span>
                                    <span className="text-lg font-bold text-primary">{formatPrice(total)}</span>
                                </div>
                            </div>

                            <Link href="/checkout" className="btn-primary w-full mt-6">
                                Proceed to Checkout <ArrowRight size={16} />
                            </Link>

                            <p className="text-xs text-gray-400 text-center mt-3">
                                or <Link href="/category/housekeeping-materials" className="text-primary hover:underline">Continue Shopping</Link>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
