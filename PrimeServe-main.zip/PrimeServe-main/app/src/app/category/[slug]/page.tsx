import Link from "next/link";
import { ChevronRight, SlidersHorizontal, Grid3X3, List } from "lucide-react";
import { categories, getProductsByCategory, products } from "@/lib/mock-data";
import ProductCard from "@/components/product/product-card";

interface Props {
    params: Promise<{ slug: string }>;
}

export async function generateStaticParams() {
    return categories.map((c) => ({ slug: c.slug }));
}

export default async function CategoryPage({ params }: Props) {
    const { slug } = await params;
    const category = categories.find((c) => c.slug === slug);
    const categoryProducts = getProductsByCategory(slug);

    // If category not found, show all products
    const displayProducts = categoryProducts.length > 0 ? categoryProducts : products;
    const displayName = category?.name || "All Products";

    return (
        <>
            {/* Breadcrumbs */}
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary transition-colors">Home</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">{displayName}</span>
                    </nav>
                </div>
            </div>

            <div className="container-custom py-6 md:py-8">
                <div className="flex flex-col lg:flex-row gap-6 lg:gap-8">
                    {/* Filter Sidebar */}
                    <aside className="lg:w-64 shrink-0">
                        <div className="lg:sticky lg:top-32">
                            <div className="flex items-center justify-between mb-4 lg:mb-6">
                                <h2 className="font-semibold text-gray-900 flex items-center gap-2">
                                    <SlidersHorizontal size={18} /> Filters
                                </h2>
                                <button className="text-xs text-primary font-medium hover:underline">
                                    Clear All
                                </button>
                            </div>

                            {/* Sub-categories */}
                            {category && (
                                <div className="mb-6">
                                    <h3 className="text-sm font-semibold text-gray-900 mb-3">Sub-category</h3>
                                    <div className="space-y-2">
                                        {category.subcategories.map((sub) => (
                                            <label key={sub.id} className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900">
                                                <input type="checkbox" className="accent-primary w-4 h-4 rounded" />
                                                {sub.name}
                                            </label>
                                        ))}
                                    </div>
                                </div>
                            )}

                            {/* Price Range */}
                            <div className="mb-6">
                                <h3 className="text-sm font-semibold text-gray-900 mb-3">Price Range</h3>
                                <div className="space-y-2">
                                    {["Under ₹200", "₹200 – ₹500", "₹500 – ₹1,000", "Above ₹1,000"].map((r) => (
                                        <label key={r} className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900">
                                            <input type="checkbox" className="accent-primary w-4 h-4 rounded" />
                                            {r}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Brand */}
                            <div className="mb-6">
                                <h3 className="text-sm font-semibold text-gray-900 mb-3">Brand</h3>
                                <div className="space-y-2">
                                    {["CleanPro", "SafeGuard", "ShinePro", "MediClean", "EcoClean"].map((b) => (
                                        <label key={b} className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900">
                                            <input type="checkbox" className="accent-primary w-4 h-4 rounded" />
                                            {b}
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Rating */}
                            <div className="mb-6">
                                <h3 className="text-sm font-semibold text-gray-900 mb-3">Rating</h3>
                                <div className="space-y-2">
                                    {[4, 3, 2].map((stars) => (
                                        <label key={stars} className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900">
                                            <input type="radio" name="rating" className="accent-primary w-4 h-4" />
                                            {stars}★ & above
                                        </label>
                                    ))}
                                </div>
                            </div>

                            {/* Availability */}
                            <div>
                                <h3 className="text-sm font-semibold text-gray-900 mb-3">Availability</h3>
                                <label className="flex items-center gap-2 text-sm text-gray-600 cursor-pointer hover:text-gray-900">
                                    <input type="checkbox" className="accent-primary w-4 h-4 rounded" />
                                    In Stock Only
                                </label>
                            </div>
                        </div>
                    </aside>

                    {/* Product Grid */}
                    <div className="flex-1">
                        {/* Header */}
                        <div className="flex items-center justify-between mb-6">
                            <div>
                                <h1 className="text-xl md:text-2xl font-bold text-gray-900">{displayName}</h1>
                                <p className="text-sm text-gray-500 mt-1">{displayProducts.length} products found</p>
                            </div>
                            <div className="flex items-center gap-3">
                                <select className="text-sm border border-border-custom rounded-lg px-3 h-9 bg-white focus:outline-none focus:ring-2 focus:ring-primary/30">
                                    <option>Sort: Relevance</option>
                                    <option>Price: Low to High</option>
                                    <option>Price: High to Low</option>
                                    <option>Newest First</option>
                                    <option>Rating</option>
                                </select>
                                <div className="hidden sm:flex border border-border-custom rounded-lg overflow-hidden">
                                    <button className="p-2 bg-primary/5 text-primary"><Grid3X3 size={16} /></button>
                                    <button className="p-2 text-gray-400 hover:text-gray-600"><List size={16} /></button>
                                </div>
                            </div>
                        </div>

                        {/* Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4 md:gap-5">
                            {displayProducts.map((p) => (
                                <ProductCard key={p.id} product={p} />
                            ))}
                        </div>

                        {/* Pagination */}
                        <div className="flex justify-center gap-2 mt-10">
                            <button className="px-3 py-2 text-sm border border-border-custom rounded-lg text-gray-400" disabled>
                                Previous
                            </button>
                            <button className="px-3 py-2 text-sm bg-primary text-white rounded-lg font-medium">1</button>
                            <button className="px-3 py-2 text-sm border border-border-custom rounded-lg text-gray-600 hover:bg-surface">2</button>
                            <button className="px-3 py-2 text-sm border border-border-custom rounded-lg text-gray-600 hover:bg-surface">3</button>
                            <button className="px-3 py-2 text-sm border border-border-custom rounded-lg text-gray-600 hover:bg-surface">
                                Next
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
