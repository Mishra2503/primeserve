import Link from "next/link";
import {
    ChevronRight,
    Target,
    Users,
    Award,
    Shield,
    Truck,
    Building2,
    Globe,
    CheckCircle2,
} from "lucide-react";

export default function AboutPage() {
    return (
        <>
            <div className="bg-surface border-b border-border-custom">
                <div className="container-custom py-3">
                    <nav className="flex items-center gap-2 text-sm text-gray-500">
                        <Link href="/" className="hover:text-primary">Home</Link>
                        <ChevronRight size={14} />
                        <span className="text-gray-900 font-medium">About Us</span>
                    </nav>
                </div>
            </div>

            {/* Hero */}
            <section className="bg-gradient-to-br from-primary to-primary-dark text-white section-padding">
                <div className="container-custom text-center max-w-3xl mx-auto">
                    <h1 className="text-3xl md:text-4xl font-bold mb-4">
                        Simplifying Facility Procurement for India&apos;s Businesses
                    </h1>
                    <p className="text-white/80 text-lg leading-relaxed">
                        PrimeServe is India&apos;s trusted B2B marketplace connecting facility managers
                        and procurement teams with premium supplies at the best prices.
                    </p>
                </div>
            </section>

            {/* Our Story */}
            <section className="section-padding">
                <div className="container-custom">
                    <div className="grid md:grid-cols-2 gap-12 items-center">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-900 mb-4">Our Story</h2>
                            <div className="space-y-4 text-gray-600 leading-relaxed">
                                <p>
                                    Founded in 2024, PrimeServe was born from a simple observation: facility
                                    managers across India were spending hours every week juggling multiple
                                    vendors, comparing prices, and chasing invoices for basic supplies.
                                </p>
                                <p>
                                    We built PrimeServe to solve this — one platform where businesses can
                                    source all their facility management needs, benefit from bulk pricing,
                                    access 45-day credit terms, and receive GST-compliant invoices
                                    automatically.
                                </p>
                                <p>
                                    Today, we serve 1,000+ businesses across India, from IT parks and
                                    corporate offices to hospitals and educational institutions.
                                </p>
                            </div>
                        </div>
                        <div className="bg-surface rounded-2xl p-8">
                            <div className="grid grid-cols-2 gap-6">
                                {[
                                    { value: "1,000+", label: "Active Businesses" },
                                    { value: "395+", label: "Products Listed" },
                                    { value: "₹2Cr+", label: "Monthly GMV" },
                                    { value: "98%", label: "On-Time Delivery" },
                                ].map((stat) => (
                                    <div key={stat.label} className="text-center">
                                        <p className="text-2xl font-bold text-primary">{stat.value}</p>
                                        <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* Values */}
            <section className="section-padding bg-surface">
                <div className="container-custom">
                    <h2 className="text-2xl font-bold text-gray-900 text-center mb-10">Our Values</h2>
                    <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
                        {[
                            {
                                icon: Target,
                                title: "Quality First",
                                desc: "Every product is vetted for quality. We partner only with trusted manufacturers and brands.",
                            },
                            {
                                icon: Shield,
                                title: "Trust & Transparency",
                                desc: "Transparent pricing, GST-compliant invoicing, and no hidden charges. What you see is what you pay.",
                            },
                            {
                                icon: Users,
                                title: "Customer Obsessed",
                                desc: "Dedicated account managers, responsive support, and flexible terms tailored to your business.",
                            },
                            {
                                icon: Globe,
                                title: "Pan-India Reach",
                                desc: "We deliver to businesses across all major cities with reliable logistics partners.",
                            },
                        ].map((v) => (
                            <div key={v.title} className="card p-6 text-center">
                                <div className="w-14 h-14 mx-auto mb-4 rounded-xl bg-primary/5 flex items-center justify-center">
                                    <v.icon size={28} className="text-primary" />
                                </div>
                                <h3 className="font-semibold text-gray-900 mb-2">{v.title}</h3>
                                <p className="text-sm text-gray-500 leading-relaxed">{v.desc}</p>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Product Range */}
            <section className="section-padding">
                <div className="container-custom text-center max-w-3xl mx-auto">
                    <h2 className="text-2xl font-bold text-gray-900 mb-4">What We Supply</h2>
                    <p className="text-gray-500 mb-8">
                        Four core categories covering every facility need — from cleaning
                        supplies to office essentials.
                    </p>
                    <div className="grid sm:grid-cols-2 gap-4 max-w-lg mx-auto text-left">
                        {[
                            "Housekeeping Materials",
                            "Cleaning Chemicals",
                            "Office Stationery",
                            "Pantry Items",
                        ].map((cat) => (
                            <div key={cat} className="flex items-center gap-3 p-3 bg-surface rounded-lg">
                                <CheckCircle2 size={20} className="text-secondary shrink-0" />
                                <span className="text-sm font-medium text-gray-700">{cat}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* Certifications */}
            <section className="section-padding bg-surface">
                <div className="container-custom text-center">
                    <h2 className="text-2xl font-bold text-gray-900 mb-3">Trusted & Certified</h2>
                    <p className="text-gray-500 mb-8">
                        We comply with all relevant Indian business standards and regulations.
                    </p>
                    <div className="flex flex-wrap justify-center gap-6">
                        {[
                            { icon: Shield, label: "GST Registered" },
                            { icon: Award, label: "ISO 9001:2015" },
                            { icon: Building2, label: "MSME Certified" },
                            { icon: Truck, label: "Pan-India Delivery" },
                        ].map((cert) => (
                            <div
                                key={cert.label}
                                className="flex items-center gap-3 bg-white px-5 py-3 rounded-xl border border-border-custom"
                            >
                                <cert.icon size={20} className="text-primary" />
                                <span className="text-sm font-medium text-gray-700">{cert.label}</span>
                            </div>
                        ))}
                    </div>
                </div>
            </section>

            {/* CTA */}
            <section className="section-padding">
                <div className="container-custom text-center max-w-2xl mx-auto">
                    <h2 className="text-2xl font-bold text-gray-900 mb-3">
                        Ready to Streamline Your Procurement?
                    </h2>
                    <p className="text-gray-500 mb-6">
                        Join 1,000+ businesses who trust PrimeServe for their facility supplies.
                    </p>
                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                        <Link href="/category/housekeeping-materials" className="btn-primary">
                            Browse Products
                        </Link>
                        <Link href="/contact" className="btn-secondary">
                            Contact Sales
                        </Link>
                    </div>
                </div>
            </section>
        </>
    );
}
