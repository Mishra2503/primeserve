export interface Category {
    id: string;
    name: string;
    slug: string;
    description: string;
    imageUrl: string;
    icon: string;
    productCount: number;
    subcategories: Subcategory[];
}

export interface Subcategory {
    id: string;
    name: string;
    slug: string;
}

export interface Product {
    id: string;
    name: string;
    slug: string;
    sku: string;
    description: string;
    shortDescription: string;
    images: string[];
    basePrice: number; // in paise
    stock: number;
    minOrderQty: number;
    maxOrderQty: number;
    unit: string;
    isActive: boolean;
    tags: string[];
    categorySlug: string;
    categoryName: string;
    subcategory: string;
    brand: string;
    rating: number;
    reviewCount: number;
    pricingTiers: BulkPricingTier[];
    specs: Record<string, string>;
    usageInstructions?: string;
    isBulkAvailable: boolean;
    isNew?: boolean;
    isFeatured?: boolean;
}

export interface BulkPricingTier {
    minQuantity: number;
    maxQuantity: number | null;
    pricePerUnit: number; // in paise
}

export interface CartItem {
    product: Product;
    quantity: number;
}

export interface Review {
    id: string;
    userName: string;
    companyName: string;
    rating: number;
    title: string;
    body: string;
    date: string;
    isVerified: boolean;
}

export interface Testimonial {
    id: string;
    quote: string;
    author: string;
    role: string;
    company: string;
    companyLogo?: string;
}

export interface Order {
    id: string;
    orderNumber: string;
    date: string;
    status: "Pending" | "Confirmed" | "Processing" | "Shipped" | "Delivered";
    items: { name: string; quantity: number; price: number }[];
    total: number;
}

export interface Address {
    id: string;
    label: string;
    companyName: string;
    contactPerson: string;
    street: string;
    city: string;
    state: string;
    pincode: string;
    phone: string;
    isDefault: boolean;
}
