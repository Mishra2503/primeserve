"use client";

import Link from "next/link";
import { useState } from "react";
import {
    Search,
    ShoppingCart,
    Heart,
    User,
    Menu,
    X,
    ChevronDown,
    Phone,
} from "lucide-react";
import { categories } from "@/lib/mock-data";

const navCategories = categories.map((c) => ({
    name: c.name,
    slug: c.slug,
}));

export default function Header() {
    const [mobileOpen, setMobileOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");

    const cartCount = 3; // mock

    return (
        <>
            {/* Top bar */}
            <div className="bg-primary text-white text-xs py-1.5 hidden md:block">
                <div className="container-custom flex justify-between items-center">
                    <div className="flex items-center gap-4">
                        <span className="flex items-center gap-1">
                            <Phone size={12} /> +91 98765 43210
                        </span>
                        <span>Mon–Sat: 9:00 AM – 7:00 PM</span>
                    </div>
                    <div className="flex items-center gap-4">
                        <span>45-Day Credit Terms Available</span>
                        <span>|</span>
                        <Link href="/pro-plan" className="font-semibold hover:text-accent-light transition-colors">
                            ⭐ Upgrade to Pro Plan
                        </Link>
                    </div>
                </div>
            </div>

            {/* Main header */}
            <header className="sticky top-0 z-50 bg-white border-b border-border-custom shadow-sm">
                <div className="container-custom flex items-center justify-between h-16 gap-4">
                    {/* Logo */}
                    <Link href="/" className="flex items-center gap-2 shrink-0">
                        <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                            <span className="text-white font-bold text-sm">PS</span>
                        </div>
                        <span className="text-xl font-bold text-primary hidden sm:block">
                            Prime<span className="text-accent">Serve</span>
                        </span>
                    </Link>

                    {/* Search Bar — Desktop */}
                    <div className="hidden md:flex flex-1 max-w-xl relative">
                        <input
                            type="text"
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            placeholder="Search products, SKUs, brands..."
                            className="w-full h-10 pl-10 pr-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary transition-all"
                        />
                        <Search
                            size={18}
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                        />
                    </div>

                    {/* Right actions */}
                    <div className="flex items-center gap-1 sm:gap-3">
                        <Link
                            href="/account"
                            className="hidden sm:flex items-center gap-1.5 text-sm text-gray-600 hover:text-primary transition-colors px-2 py-2"
                        >
                            <Heart size={20} />
                            <span className="hidden lg:inline">Favorites</span>
                        </Link>
                        <Link
                            href="/cart"
                            className="relative flex items-center gap-1.5 text-sm text-gray-600 hover:text-primary transition-colors px-2 py-2"
                        >
                            <ShoppingCart size={20} />
                            {cartCount > 0 && (
                                <span className="absolute -top-0.5 -right-0.5 bg-error text-white text-[10px] font-bold w-4.5 h-4.5 rounded-full flex items-center justify-center leading-none">
                                    {cartCount}
                                </span>
                            )}
                            <span className="hidden lg:inline">Cart</span>
                        </Link>
                        <Link
                            href="/account"
                            className="hidden sm:flex items-center gap-1.5 text-sm text-gray-600 hover:text-primary transition-colors px-2 py-2"
                        >
                            <User size={20} />
                            <span className="hidden lg:inline">Account</span>
                        </Link>
                        <button
                            className="md:hidden p-2 text-gray-600"
                            onClick={() => setMobileOpen(true)}
                            aria-label="Open menu"
                        >
                            <Menu size={24} />
                        </button>
                    </div>
                </div>

                {/* Category Navigation — Desktop */}
                <nav className="hidden md:block bg-surface border-t border-border-custom">
                    <div className="container-custom flex items-center gap-1 h-11">
                        <Link
                            href="/"
                            className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-primary/5 rounded-md transition-colors"
                        >
                            Home
                        </Link>
                        {navCategories.map((cat) => (
                            <Link
                                key={cat.slug}
                                href={`/category/${cat.slug}`}
                                className="px-3 py-2 text-sm font-medium text-gray-700 hover:text-primary hover:bg-primary/5 rounded-md transition-colors flex items-center gap-1"
                            >
                                {cat.name}
                                <ChevronDown size={14} className="opacity-50" />
                            </Link>
                        ))}
                        <Link
                            href="/pro-plan"
                            className="px-3 py-2 text-sm font-semibold text-accent hover:bg-accent/5 rounded-md transition-colors ml-auto"
                        >
                            ⭐ Pro Plan
                        </Link>
                    </div>
                </nav>
            </header>

            {/* Mobile Drawer */}
            {mobileOpen && (
                <div className="fixed inset-0 z-[60] md:hidden">
                    <div
                        className="absolute inset-0 bg-black/40"
                        onClick={() => setMobileOpen(false)}
                    />
                    <div className="absolute left-0 top-0 bottom-0 w-72 bg-white shadow-xl flex flex-col animate-in slide-in-from-left">
                        <div className="flex items-center justify-between p-4 border-b border-border-custom">
                            <span className="text-lg font-bold text-primary">
                                Prime<span className="text-accent">Serve</span>
                            </span>
                            <button
                                onClick={() => setMobileOpen(false)}
                                className="p-1 text-gray-500"
                                aria-label="Close menu"
                            >
                                <X size={24} />
                            </button>
                        </div>
                        {/* Mobile search */}
                        <div className="p-4">
                            <div className="relative">
                                <input
                                    type="text"
                                    placeholder="Search products..."
                                    className="w-full h-10 pl-10 pr-4 border border-border-custom rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary/30"
                                />
                                <Search
                                    size={18}
                                    className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"
                                />
                            </div>
                        </div>
                        <nav className="flex-1 overflow-y-auto px-2">
                            <Link
                                href="/"
                                className="block px-4 py-3 text-sm font-medium text-gray-700 hover:bg-surface rounded-lg"
                                onClick={() => setMobileOpen(false)}
                            >
                                Home
                            </Link>
                            {navCategories.map((cat) => (
                                <Link
                                    key={cat.slug}
                                    href={`/category/${cat.slug}`}
                                    className="block px-4 py-3 text-sm font-medium text-gray-700 hover:bg-surface rounded-lg"
                                    onClick={() => setMobileOpen(false)}
                                >
                                    {cat.name}
                                </Link>
                            ))}
                            <div className="border-t border-border-custom my-2" />
                            <Link
                                href="/about"
                                className="block px-4 py-3 text-sm text-gray-600 hover:bg-surface rounded-lg"
                                onClick={() => setMobileOpen(false)}
                            >
                                About Us
                            </Link>
                            <Link
                                href="/services"
                                className="block px-4 py-3 text-sm text-gray-600 hover:bg-surface rounded-lg"
                                onClick={() => setMobileOpen(false)}
                            >
                                Services
                            </Link>
                            <Link
                                href="/contact"
                                className="block px-4 py-3 text-sm text-gray-600 hover:bg-surface rounded-lg"
                                onClick={() => setMobileOpen(false)}
                            >
                                Contact Us
                            </Link>
                            <Link
                                href="/pro-plan"
                                className="block px-4 py-3 text-sm font-semibold text-accent hover:bg-accent/5 rounded-lg"
                                onClick={() => setMobileOpen(false)}
                            >
                                ⭐ Pro Plan
                            </Link>
                        </nav>
                    </div>
                </div>
            )}
        </>
    );
}
