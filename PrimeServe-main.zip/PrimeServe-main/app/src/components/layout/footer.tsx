import Link from "next/link";
import {
    Phone,
    Mail,
    MapPin,
    Facebook,
    Twitter,
    Linkedin,
    Instagram,
} from "lucide-react";

export default function Footer() {
    return (
        <footer className="bg-[#0F172A] text-gray-300">
            {/* Main footer */}
            <div className="container-custom section-padding">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 lg:gap-12">
                    {/* Column 1 — Company */}
                    <div>
                        <Link href="/" className="flex items-center gap-2 mb-4">
                            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                                <span className="text-white font-bold text-sm">PS</span>
                            </div>
                            <span className="text-xl font-bold text-white">
                                Prime<span className="text-accent">Serve</span>
                            </span>
                        </Link>
                        <p className="text-sm text-gray-400 mb-4 leading-relaxed">
                            India&apos;s trusted B2B marketplace for facility management &amp; office
                            supplies. Serving 1,000+ businesses across the country.
                        </p>
                        <div className="flex gap-3">
                            {[Facebook, Twitter, Linkedin, Instagram].map((Icon, i) => (
                                <a
                                    key={i}
                                    href="#"
                                    className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center hover:bg-primary transition-colors"
                                    aria-label="Social link"
                                >
                                    <Icon size={16} />
                                </a>
                            ))}
                        </div>
                    </div>

                    {/* Column 2 — Categories */}
                    <div>
                        <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
                            Categories
                        </h3>
                        <ul className="space-y-2.5">
                            {[
                                { name: "Housekeeping Materials", href: "/category/housekeeping-materials" },
                                { name: "Cleaning Chemicals", href: "/category/cleaning-chemicals" },
                                { name: "Office Stationery", href: "/category/office-stationery" },
                                { name: "Pantry Items", href: "/category/pantry-items" },
                            ].map((link) => (
                                <li key={link.href}>
                                    <Link
                                        href={link.href}
                                        className="text-sm text-gray-400 hover:text-white transition-colors"
                                    >
                                        {link.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Column 3 — Support */}
                    <div>
                        <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
                            Company
                        </h3>
                        <ul className="space-y-2.5">
                            {[
                                { name: "About Us", href: "/about" },
                                { name: "Our Services", href: "/services" },
                                { name: "Pro Plan", href: "/pro-plan" },
                                { name: "Contact Us", href: "/contact" },
                                { name: "FAQs", href: "#" },
                                { name: "Terms & Conditions", href: "#" },
                            ].map((link) => (
                                <li key={link.href + link.name}>
                                    <Link
                                        href={link.href}
                                        className="text-sm text-gray-400 hover:text-white transition-colors"
                                    >
                                        {link.name}
                                    </Link>
                                </li>
                            ))}
                        </ul>
                    </div>

                    {/* Column 4 — Contact */}
                    <div>
                        <h3 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">
                            Get in Touch
                        </h3>
                        <ul className="space-y-3">
                            <li className="flex items-start gap-3 text-sm">
                                <Phone size={16} className="mt-0.5 text-secondary shrink-0" />
                                <div>
                                    <p className="text-white font-medium">+91 98765 43210</p>
                                    <p className="text-gray-500 text-xs">Mon–Sat, 9AM–7PM</p>
                                </div>
                            </li>
                            <li className="flex items-start gap-3 text-sm">
                                <Mail size={16} className="mt-0.5 text-secondary shrink-0" />
                                <div>
                                    <p className="text-white font-medium">orders@primeserve.com</p>
                                    <p className="text-gray-500 text-xs">Response within 2 hrs</p>
                                </div>
                            </li>
                            <li className="flex items-start gap-3 text-sm">
                                <MapPin size={16} className="mt-0.5 text-secondary shrink-0" />
                                <p className="text-gray-400">
                                    Tower A, Business Park, Sector 62, Noida, UP 201309
                                </p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>

            {/* Bottom bar */}
            <div className="border-t border-white/10">
                <div className="container-custom py-4 flex flex-col sm:flex-row items-center justify-between gap-2 text-sm text-gray-500">
                    <p>&copy; 2026 PrimeServe. All rights reserved.</p>
                    <div className="flex gap-4">
                        <Link href="#" className="hover:text-gray-300 transition-colors">Privacy Policy</Link>
                        <Link href="#" className="hover:text-gray-300 transition-colors">Terms of Service</Link>
                        <Link href="#" className="hover:text-gray-300 transition-colors">Refund Policy</Link>
                    </div>
                </div>
            </div>
        </footer>
    );
}
