"use client";

import Link from "next/link";
import { Star, ShoppingCart, TrendingDown } from "lucide-react";
import { Product } from "@/types";
import { formatPrice } from "@/lib/utils";

interface ProductCardProps {
    product: Product;
}

export default function ProductCard({ product }: ProductCardProps) {
    const bestPrice =
        product.pricingTiers.length > 0
            ? product.pricingTiers[product.pricingTiers.length - 1].pricePerUnit
            : product.basePrice;
    const savings = product.basePrice - bestPrice;

    return (
        <Link
            href={`/product/${product.slug}`}
            className="card group block"
        >
            {/* Image */}
            <div className="relative aspect-square bg-gray-50 overflow-hidden">
                <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    loading="lazy"
                />
                {/* Badges */}
                <div className="absolute top-3 left-3 flex flex-col gap-1.5">
                    {product.isNew && (
                        <span className="badge badge-info">New</span>
                    )}
                    {product.isBulkAvailable && savings > 0 && (
                        <span className="badge badge-success flex items-center gap-1">
                            <TrendingDown size={12} />
                            Save up to {Math.round((savings / product.basePrice) * 100)}%
                        </span>
                    )}
                </div>
                {product.stock < 20 && (
                    <span className="absolute top-3 right-3 badge badge-warning">
                        Low Stock
                    </span>
                )}
            </div>

            {/* Info */}
            <div className="p-4">
                <p className="text-xs text-gray-400 mb-1">
                    {product.brand} • {product.subcategory}
                </p>
                <h3 className="text-sm font-semibold text-gray-900 mb-1.5 line-clamp-2 group-hover:text-primary transition-colors">
                    {product.name}
                </h3>

                {/* Rating */}
                <div className="flex items-center gap-1 mb-2">
                    <div className="flex items-center">
                        {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                                key={i}
                                size={12}
                                className={
                                    i < Math.floor(product.rating)
                                        ? "fill-accent text-accent"
                                        : "text-gray-200"
                                }
                            />
                        ))}
                    </div>
                    <span className="text-xs text-gray-500">
                        ({product.reviewCount})
                    </span>
                </div>

                {/* Price */}
                <div className="flex items-baseline gap-2 mb-3">
                    <span className="text-lg font-bold text-primary">
                        {formatPrice(product.basePrice)}
                    </span>
                    <span className="text-xs text-gray-400">/{product.unit}</span>
                </div>

                {/* Bulk pricing note */}
                {product.isBulkAvailable && (
                    <p className="text-xs text-secondary font-medium mb-3">
                        Bulk pricing from {formatPrice(bestPrice)}/{product.unit}
                    </p>
                )}

                {/* Add to cart button */}
                <button
                    className="btn-primary w-full text-xs h-9"
                    onClick={(e) => {
                        e.preventDefault();
                        e.stopPropagation();
                    }}
                >
                    <ShoppingCart size={14} />
                    Add to Cart
                </button>
            </div>
        </Link>
    );
}
