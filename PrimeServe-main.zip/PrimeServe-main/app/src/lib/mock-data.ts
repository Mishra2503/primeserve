import { Category, Product, Testimonial, Review, Order, Address } from "@/types";

export const categories: Category[] = [
    {
        id: "1",
        name: "Housekeeping Materials",
        slug: "housekeeping-materials",
        description: "Premium quality mops, brooms, dusters, trash bags, gloves, and cleaning tools for professional facility maintenance.",
        imageUrl: "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=600&h=400&fit=crop",
        icon: "Brush",
        productCount: 96,
        subcategories: [
            { id: "1a", name: "Mops & Brooms", slug: "mops-brooms" },
            { id: "1b", name: "Dusters & Wipers", slug: "dusters-wipers" },
            { id: "1c", name: "Trash Bags & Bins", slug: "trash-bags-bins" },
            { id: "1d", name: "Gloves & Safety", slug: "gloves-safety" },
        ],
    },
    {
        id: "2",
        name: "Cleaning Chemicals",
        slug: "cleaning-chemicals",
        description: "Industrial-grade floor cleaners, disinfectants, glass cleaners, and sanitizers for spotless commercial spaces.",
        imageUrl: "https://images.unsplash.com/photo-1563453392212-326f5e854473?w=600&h=400&fit=crop",
        icon: "FlaskConical",
        productCount: 78,
        subcategories: [
            { id: "2a", name: "Floor Cleaners", slug: "floor-cleaners" },
            { id: "2b", name: "Disinfectants", slug: "disinfectants" },
            { id: "2c", name: "Glass Cleaners", slug: "glass-cleaners" },
            { id: "2d", name: "Hand Wash & Sanitizers", slug: "hand-wash-sanitizers" },
        ],
    },
    {
        id: "3",
        name: "Office Stationery",
        slug: "office-stationery",
        description: "Complete range of pens, notebooks, files, folders, markers, and all essential office supplies for your workspace.",
        imageUrl: "https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600&h=400&fit=crop",
        icon: "Pencil",
        productCount: 134,
        subcategories: [
            { id: "3a", name: "Pens & Writing", slug: "pens-writing" },
            { id: "3b", name: "Notebooks & Pads", slug: "notebooks-pads" },
            { id: "3c", name: "Files & Folders", slug: "files-folders" },
            { id: "3d", name: "Tapes & Adhesives", slug: "tapes-adhesives" },
        ],
    },
    {
        id: "4",
        name: "Pantry Items",
        slug: "pantry-items",
        description: "Quality tea, coffee, sugar, disposable cups, napkins, and refreshment supplies to keep your team energized.",
        imageUrl: "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=400&fit=crop",
        icon: "Coffee",
        productCount: 87,
        subcategories: [
            { id: "4a", name: "Tea & Coffee", slug: "tea-coffee" },
            { id: "4b", name: "Sugar & Sweeteners", slug: "sugar-sweeteners" },
            { id: "4c", name: "Disposable Cups & Plates", slug: "disposable-cups-plates" },
            { id: "4d", name: "Snacks & Beverages", slug: "snacks-beverages" },
        ],
    },
];

export const products: Product[] = [
    // Housekeeping Materials
    {
        id: "p1", name: "Industrial Wet Mop Set", slug: "industrial-wet-mop-set", sku: "HK-MOP-001",
        description: "Heavy-duty wet mop with stainless steel handle and ultra-absorbent microfiber head. Perfect for large commercial floors. The microfiber head is machine washable up to 500 times, making it an economical and eco-friendly choice for professional cleaning operations.",
        shortDescription: "Heavy-duty wet mop with stainless steel handle and microfiber head.",
        images: ["https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=600&h=600&fit=crop", "https://images.unsplash.com/photo-1563453392212-326f5e854473?w=600&h=600&fit=crop"],
        basePrice: 45000, stock: 250, minOrderQty: 1, maxOrderQty: 500, unit: "piece",
        isActive: true, tags: ["mop", "housekeeping", "microfiber"], categorySlug: "housekeeping-materials",
        categoryName: "Housekeeping Materials", subcategory: "Mops & Brooms", brand: "CleanPro",
        rating: 4.5, reviewCount: 48,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 45000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 40000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 35000 },
        ],
        specs: { "Handle Material": "Stainless Steel", "Head Material": "Microfiber", "Handle Length": "150cm", "Head Width": "40cm", "Weight": "800g" },
        isBulkAvailable: true, isFeatured: true,
    },
    {
        id: "p2", name: "Premium Nitrile Gloves (Box of 100)", slug: "premium-nitrile-gloves", sku: "HK-GLV-002",
        description: "Powder-free nitrile examination gloves. Textured fingertips for superior grip. Suitable for cleaning, food handling, and general facility maintenance.",
        shortDescription: "Powder-free nitrile gloves with textured grip, box of 100.",
        images: ["https://images.unsplash.com/photo-1583947215259-38e31be8751f?w=600&h=600&fit=crop"],
        basePrice: 65000, stock: 500, minOrderQty: 1, maxOrderQty: 1000, unit: "box",
        isActive: true, tags: ["gloves", "nitrile", "safety"], categorySlug: "housekeeping-materials",
        categoryName: "Housekeeping Materials", subcategory: "Gloves & Safety", brand: "SafeGuard",
        rating: 4.7, reviewCount: 112,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 24, pricePerUnit: 65000 },
            { minQuantity: 25, maxQuantity: 99, pricePerUnit: 58000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 52000 },
        ],
        specs: { "Material": "Nitrile", "Powder": "Free", "Size": "Medium/Large", "Quantity": "100 per box", "Thickness": "4 mil" },
        isBulkAvailable: true, isNew: true, isFeatured: true,
    },
    {
        id: "p3", name: "Microfiber Cleaning Cloth (Pack of 12)", slug: "microfiber-cleaning-cloth-12", sku: "HK-CLT-003",
        description: "Ultra-soft, lint-free microfiber cloths ideal for dusting, polishing, and surface cleaning. Machine washable up to 500 uses.",
        shortDescription: "12-pack ultra-soft microfiber cloths for all surfaces.",
        images: ["https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=600&h=600&fit=crop"],
        basePrice: 32000, stock: 800, minOrderQty: 1, maxOrderQty: 500, unit: "pack",
        isActive: true, tags: ["microfiber", "cloth", "cleaning"], categorySlug: "housekeeping-materials",
        categoryName: "Housekeeping Materials", subcategory: "Dusters & Wipers", brand: "CleanPro",
        rating: 4.3, reviewCount: 67,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 32000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 28000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 24000 },
        ],
        specs: { "Material": "80% Polyester, 20% Polyamide", "Size": "40cm x 40cm", "GSM": "300", "Pack": "12 cloths" },
        isBulkAvailable: true,
    },
    {
        id: "p4", name: "Heavy Duty Garbage Bags (Pack of 50)", slug: "heavy-duty-garbage-bags", sku: "HK-BAG-004",
        description: "Extra-strong biodegradable garbage bags for commercial use. Leak-proof with drawstring closure.",
        shortDescription: "50-pack extra-strong biodegradable bags with drawstring.",
        images: ["https://images.unsplash.com/photo-1610141499627-1e0e3adf4dc9?w=600&h=600&fit=crop"],
        basePrice: 28000, stock: 600, minOrderQty: 5, maxOrderQty: 500, unit: "pack",
        isActive: true, tags: ["garbage bags", "waste", "biodegradable"], categorySlug: "housekeeping-materials",
        categoryName: "Housekeeping Materials", subcategory: "Trash Bags & Bins", brand: "EcoClean",
        rating: 4.1, reviewCount: 34,
        pricingTiers: [
            { minQuantity: 5, maxQuantity: 49, pricePerUnit: 28000 },
            { minQuantity: 50, maxQuantity: 199, pricePerUnit: 24000 },
            { minQuantity: 200, maxQuantity: null, pricePerUnit: 21000 },
        ],
        specs: { "Capacity": "60 litres", "Material": "Biodegradable HDPE", "Closure": "Drawstring", "Pack": "50 bags" },
        isBulkAvailable: true,
    },
    // Cleaning Chemicals
    {
        id: "p5", name: "Commercial Floor Cleaner (5L)", slug: "commercial-floor-cleaner-5l", sku: "CC-FLR-001",
        description: "Concentrated multi-surface floor cleaner with fresh citrus scent. Removes tough stains and leaves a streak-free shine. Dilution ratio 1:50 for economical usage.",
        shortDescription: "5L concentrated floor cleaner with citrus scent, 1:50 dilution.",
        images: ["https://images.unsplash.com/photo-1563453392212-326f5e854473?w=600&h=600&fit=crop", "https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=600&h=600&fit=crop"],
        basePrice: 89000, stock: 300, minOrderQty: 1, maxOrderQty: 200, unit: "can",
        isActive: true, tags: ["floor cleaner", "concentrated", "citrus"], categorySlug: "cleaning-chemicals",
        categoryName: "Cleaning Chemicals", subcategory: "Floor Cleaners", brand: "ShinePro",
        rating: 4.6, reviewCount: 89,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 19, pricePerUnit: 89000 },
            { minQuantity: 20, maxQuantity: 49, pricePerUnit: 80000 },
            { minQuantity: 50, maxQuantity: null, pricePerUnit: 72000 },
        ],
        specs: { "Volume": "5 Litres", "Dilution": "1:50", "Fragrance": "Citrus", "pH": "Neutral", "Surface": "Multi-surface" },
        usageInstructions: "Dilute 20ml per litre of water. Apply with mop or spray. No rinsing required for routine cleaning.",
        isBulkAvailable: true, isFeatured: true,
    },
    {
        id: "p6", name: "Hospital-Grade Disinfectant (1L)", slug: "hospital-grade-disinfectant", sku: "CC-DIS-002",
        description: "Quaternary ammonium-based disinfectant that kills 99.9% of germs. Suitable for healthcare, offices, and food processing facilities.",
        shortDescription: "1L hospital-grade disinfectant, kills 99.9% germs.",
        images: ["https://images.unsplash.com/photo-1584820927498-cfe5211fd8bf?w=600&h=600&fit=crop"],
        basePrice: 42000, stock: 450, minOrderQty: 1, maxOrderQty: 500, unit: "bottle",
        isActive: true, tags: ["disinfectant", "hospital grade", "sanitizer"], categorySlug: "cleaning-chemicals",
        categoryName: "Cleaning Chemicals", subcategory: "Disinfectants", brand: "MediClean",
        rating: 4.8, reviewCount: 156,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 42000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 37000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 33000 },
        ],
        specs: { "Volume": "1 Litre", "Active Ingredient": "Quaternary Ammonium", "Kill Rate": "99.9%", "Dilution": "1:100" },
        usageInstructions: "Dilute 10ml per litre of water for surface disinfection. Allow 2 minutes contact time for full efficacy.",
        isBulkAvailable: true, isFeatured: true,
    },
    {
        id: "p7", name: "Glass & Mirror Cleaner Spray (500ml)", slug: "glass-mirror-cleaner-spray", sku: "CC-GLS-003",
        description: "Ammonia-free glass cleaner that provides streak-free shine on glass, mirrors, and chrome surfaces.",
        shortDescription: "500ml ammonia-free glass cleaner spray, streak-free.",
        images: ["https://images.unsplash.com/photo-1563453392212-326f5e854473?w=600&h=600&fit=crop"],
        basePrice: 18000, stock: 700, minOrderQty: 1, maxOrderQty: 500, unit: "bottle",
        isActive: true, tags: ["glass cleaner", "mirror", "spray"], categorySlug: "cleaning-chemicals",
        categoryName: "Cleaning Chemicals", subcategory: "Glass Cleaners", brand: "ShinePro",
        rating: 4.2, reviewCount: 43,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 18000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 15000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 13000 },
        ],
        specs: { "Volume": "500ml", "Type": "Spray", "Ammonia": "Free", "Surface": "Glass, Mirror, Chrome" },
        isBulkAvailable: true,
    },
    // Office Stationery
    {
        id: "p8", name: "Blue Ballpoint Pens (Box of 50)", slug: "blue-ballpoint-pens-50", sku: "OS-PEN-001",
        description: "Smooth-writing blue ballpoint pens with comfortable rubber grip. Ideal for everyday office use. 0.7mm tip for fine, consistent lines.",
        shortDescription: "50-pack blue ballpoint pens with rubber grip, 0.7mm tip.",
        images: ["https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600&h=600&fit=crop"],
        basePrice: 35000, stock: 1000, minOrderQty: 1, maxOrderQty: 500, unit: "box",
        isActive: true, tags: ["pens", "ballpoint", "blue"], categorySlug: "office-stationery",
        categoryName: "Office Stationery", subcategory: "Pens & Writing", brand: "WriteRight",
        rating: 4.4, reviewCount: 203,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 24, pricePerUnit: 35000 },
            { minQuantity: 25, maxQuantity: 99, pricePerUnit: 30000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 26000 },
        ],
        specs: { "Ink Color": "Blue", "Tip Size": "0.7mm", "Grip": "Rubber", "Quantity": "50 per box" },
        isBulkAvailable: true, isFeatured: true,
    },
    {
        id: "p9", name: "A4 Spiral Notebooks (Pack of 10)", slug: "a4-spiral-notebooks-10", sku: "OS-NB-002",
        description: "200-page ruled A4 spiral notebooks with hard cover. Premium quality paper that prevents ink bleed-through.",
        shortDescription: "10-pack A4 spiral notebooks, 200 pages, hard cover.",
        images: ["https://images.unsplash.com/photo-1531346878377-a5be20888e57?w=600&h=600&fit=crop"],
        basePrice: 48000, stock: 400, minOrderQty: 1, maxOrderQty: 200, unit: "pack",
        isActive: true, tags: ["notebook", "A4", "spiral"], categorySlug: "office-stationery",
        categoryName: "Office Stationery", subcategory: "Notebooks & Pads", brand: "ClassicNote",
        rating: 4.3, reviewCount: 87,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 19, pricePerUnit: 48000 },
            { minQuantity: 20, maxQuantity: 49, pricePerUnit: 42000 },
            { minQuantity: 50, maxQuantity: null, pricePerUnit: 38000 },
        ],
        specs: { "Size": "A4", "Pages": "200", "Ruling": "Lined", "Cover": "Hard Cover", "Pack": "10 notebooks" },
        isBulkAvailable: true,
    },
    {
        id: "p10", name: "Manila File Folders (Pack of 25)", slug: "manila-file-folders-25", sku: "OS-FLD-003",
        description: "Durable manila file folders with reinforced tabs. Perfect for organizing office documents.",
        shortDescription: "25-pack durable manila file folders with reinforced tabs.",
        images: ["https://images.unsplash.com/photo-1586281380349-632531db7ed4?w=600&h=600&fit=crop"],
        basePrice: 22000, stock: 600, minOrderQty: 1, maxOrderQty: 500, unit: "pack",
        isActive: true, tags: ["folders", "files", "manila"], categorySlug: "office-stationery",
        categoryName: "Office Stationery", subcategory: "Files & Folders", brand: "OfficeMate",
        rating: 4.0, reviewCount: 45,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 22000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 19000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 16000 },
        ],
        specs: { "Size": "A4/Legal", "Material": "Manila Card", "Tab": "Reinforced", "Pack": "25 folders" },
        isBulkAvailable: true,
    },
    // Pantry Items
    {
        id: "p11", name: "Premium Assam Tea (1kg)", slug: "premium-assam-tea-1kg", sku: "PT-TEA-001",
        description: "Rich, full-bodied Assam CTC tea. Perfect for office pantries. Strong flavor with golden-amber color. Packed in airtight pouches for freshness.",
        shortDescription: "1kg premium Assam CTC tea for office pantries.",
        images: ["https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=600&fit=crop"],
        basePrice: 55000, stock: 350, minOrderQty: 1, maxOrderQty: 200, unit: "pack",
        isActive: true, tags: ["tea", "assam", "CTC"], categorySlug: "pantry-items",
        categoryName: "Pantry Items", subcategory: "Tea & Coffee", brand: "TeaLeaf",
        rating: 4.6, reviewCount: 134,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 19, pricePerUnit: 55000 },
            { minQuantity: 20, maxQuantity: 49, pricePerUnit: 48000 },
            { minQuantity: 50, maxQuantity: null, pricePerUnit: 42000 },
        ],
        specs: { "Type": "CTC", "Origin": "Assam", "Weight": "1 kg", "Packaging": "Airtight Pouch" },
        isBulkAvailable: true, isFeatured: true,
    },
    {
        id: "p12", name: "Disposable Paper Cups 200ml (Pack of 100)", slug: "disposable-paper-cups-200ml", sku: "PT-CUP-002",
        description: "Single-wall paper cups with PE lining for hot and cold beverages. Eco-friendly and biodegradable.",
        shortDescription: "100-pack single-wall paper cups, 200ml, eco-friendly.",
        images: ["https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=600&fit=crop"],
        basePrice: 15000, stock: 800, minOrderQty: 5, maxOrderQty: 1000, unit: "pack",
        isActive: true, tags: ["cups", "disposable", "paper", "eco"], categorySlug: "pantry-items",
        categoryName: "Pantry Items", subcategory: "Disposable Cups & Plates", brand: "EcoCup",
        rating: 4.1, reviewCount: 78,
        pricingTiers: [
            { minQuantity: 5, maxQuantity: 49, pricePerUnit: 15000 },
            { minQuantity: 50, maxQuantity: 199, pricePerUnit: 12500 },
            { minQuantity: 200, maxQuantity: null, pricePerUnit: 10000 },
        ],
        specs: { "Capacity": "200ml", "Material": "Paper + PE Lining", "Biodegradable": "Yes", "Pack": "100 cups" },
        isBulkAvailable: true,
    },
    {
        id: "p13", name: "Instant Coffee Sachets (Box of 50)", slug: "instant-coffee-sachets-50", sku: "PT-COF-003",
        description: "Premium instant coffee sachets, individually packed for freshness. Rich flavor with smooth finish. Perfect for office vending and self-serve stations.",
        shortDescription: "50 individually packed instant coffee sachets.",
        images: ["https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=600&fit=crop"],
        basePrice: 62000, stock: 250, minOrderQty: 1, maxOrderQty: 200, unit: "box",
        isActive: true, tags: ["coffee", "instant", "sachets"], categorySlug: "pantry-items",
        categoryName: "Pantry Items", subcategory: "Tea & Coffee", brand: "BrewBox",
        rating: 4.4, reviewCount: 92,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 19, pricePerUnit: 62000 },
            { minQuantity: 20, maxQuantity: 49, pricePerUnit: 55000 },
            { minQuantity: 50, maxQuantity: null, pricePerUnit: 48000 },
        ],
        specs: { "Type": "Instant", "Pack": "50 sachets", "Weight per sachet": "2g", "Total Weight": "100g" },
        isBulkAvailable: true, isFeatured: true,
    },
    {
        id: "p14", name: "Sugar Sachets (Box of 200)", slug: "sugar-sachets-200", sku: "PT-SUG-004",
        description: "White refined sugar in individual sachets. Hygienic, portion-controlled, and convenient for office pantries.",
        shortDescription: "200 individual white sugar sachets, 5g each.",
        images: ["https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=600&h=600&fit=crop"],
        basePrice: 25000, stock: 500, minOrderQty: 1, maxOrderQty: 500, unit: "box",
        isActive: true, tags: ["sugar", "sachets"], categorySlug: "pantry-items",
        categoryName: "Pantry Items", subcategory: "Sugar & Sweeteners", brand: "SweetServe",
        rating: 4.0, reviewCount: 56,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 25000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 22000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 19000 },
        ],
        specs: { "Weight per sachet": "5g", "Pack": "200 sachets", "Type": "White Refined" },
        isBulkAvailable: true,
    },
    // Additional products for variety
    {
        id: "p15", name: "Heavy-Duty Scrub Pads (Pack of 20)", slug: "heavy-duty-scrub-pads-20", sku: "HK-SCR-005",
        description: "Industrial-strength green scrub pads for heavy-duty cleaning. Works on all hard surfaces.",
        shortDescription: "20-pack industrial scrub pads for heavy-duty cleaning.",
        images: ["https://images.unsplash.com/photo-1585421514284-efb74c2b69ba?w=600&h=600&fit=crop"],
        basePrice: 18000, stock: 500, minOrderQty: 1, maxOrderQty: 500, unit: "pack",
        isActive: true, tags: ["scrub pad", "cleaning", "heavy duty"], categorySlug: "housekeeping-materials",
        categoryName: "Housekeeping Materials", subcategory: "Dusters & Wipers", brand: "CleanPro",
        rating: 4.2, reviewCount: 38,
        pricingTiers: [
            { minQuantity: 1, maxQuantity: 49, pricePerUnit: 18000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 15000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 12000 },
        ],
        specs: { "Material": "Nylon/Polyester", "Size": "15cm x 10cm", "Pack": "20 pads" },
        isBulkAvailable: true,
    },
    {
        id: "p16", name: "Toilet Bowl Cleaner (750ml)", slug: "toilet-bowl-cleaner-750ml", sku: "CC-TBC-004",
        description: "Thick, clinging formula that removes tough stains and kills 99.9% germs. Fresh lavender fragrance.",
        shortDescription: "750ml thick toilet cleaner, lavender scent.",
        images: ["https://images.unsplash.com/photo-1563453392212-326f5e854473?w=600&h=600&fit=crop"],
        basePrice: 12000, stock: 600, minOrderQty: 5, maxOrderQty: 500, unit: "bottle",
        isActive: true, tags: ["toilet cleaner", "lavender", "disinfectant"], categorySlug: "cleaning-chemicals",
        categoryName: "Cleaning Chemicals", subcategory: "Disinfectants", brand: "MediClean",
        rating: 4.3, reviewCount: 67,
        pricingTiers: [
            { minQuantity: 5, maxQuantity: 49, pricePerUnit: 12000 },
            { minQuantity: 50, maxQuantity: 99, pricePerUnit: 10000 },
            { minQuantity: 100, maxQuantity: null, pricePerUnit: 8500 },
        ],
        specs: { "Volume": "750ml", "Fragrance": "Lavender", "Active": "Hydrochloric Acid" },
        usageInstructions: "Apply under rim and on bowl surface. Leave for 10 minutes. Scrub and flush.",
        isBulkAvailable: true,
    },
];

export const testimonials: Testimonial[] = [
    {
        id: "t1",
        quote: "PrimeServe transformed our procurement process. The 45-day credit terms and bulk pricing saved us over 20% on our annual facility supplies budget.",
        author: "Rajesh Kumar",
        role: "Facility Manager",
        company: "Infosys BPO",
    },
    {
        id: "t2",
        quote: "As a property manager handling 15 buildings, having one reliable supplier for all housekeeping materials is invaluable. Their Pro plan pays for itself within the first month.",
        author: "Priya Sharma",
        role: "Head of Operations",
        company: "DLF Group",
    },
    {
        id: "t3",
        quote: "The dedicated account manager understands our needs perfectly. Reordering is a breeze, and delivery is always on time. Highly recommended for any business.",
        author: "Amit Patel",
        role: "Procurement Director",
        company: "WeWork India",
    },
];

export const reviews: Review[] = [
    {
        id: "r1", userName: "Suresh M.", companyName: "TCS", rating: 5,
        title: "Excellent quality, consistent supply",
        body: "We have been using these products for 6 months now and the quality is consistently excellent. Great value for bulk orders.",
        date: "2026-02-10", isVerified: true,
    },
    {
        id: "r2", userName: "Anita R.", companyName: "Wipro", rating: 4,
        title: "Good product, reliable delivery",
        body: "Product quality is good. Delivery was on time. Slightly pricey for small quantities but the bulk pricing makes up for it.",
        date: "2026-01-28", isVerified: true,
    },
    {
        id: "r3", userName: "Vikram S.", companyName: "HCL", rating: 5,
        title: "Best supplier we've worked with",
        body: "Switched from our previous supplier and the difference is night and day. Better prices, better quality, better support.",
        date: "2026-01-15", isVerified: true,
    },
];

export const sampleOrders: Order[] = [
    {
        id: "o1", orderNumber: "PS-2026-00142", date: "2026-02-20", status: "Delivered",
        items: [
            { name: "Industrial Wet Mop Set", quantity: 10, price: 400000 },
            { name: "Premium Nitrile Gloves", quantity: 25, price: 1450000 },
        ],
        total: 1850000,
    },
    {
        id: "o2", orderNumber: "PS-2026-00156", date: "2026-02-22", status: "Shipped",
        items: [
            { name: "Commercial Floor Cleaner (5L)", quantity: 20, price: 1600000 },
            { name: "Glass & Mirror Cleaner Spray", quantity: 50, price: 750000 },
        ],
        total: 2350000,
    },
    {
        id: "o3", orderNumber: "PS-2026-00163", date: "2026-02-24", status: "Processing",
        items: [
            { name: "Premium Assam Tea (1kg)", quantity: 10, price: 480000 },
            { name: "Instant Coffee Sachets", quantity: 20, price: 1100000 },
            { name: "Sugar Sachets (Box of 200)", quantity: 10, price: 220000 },
        ],
        total: 1800000,
    },
];

export const sampleAddresses: Address[] = [
    {
        id: "a1", label: "Head Office", companyName: "TechCorp Solutions Pvt Ltd",
        contactPerson: "Rajesh Kumar", street: "Floor 5, Tower B, Cyber City",
        city: "Gurgaon", state: "Haryana", pincode: "122001", phone: "+91 98765 43210",
        isDefault: true,
    },
    {
        id: "a2", label: "Branch Office", companyName: "TechCorp Solutions Pvt Ltd",
        contactPerson: "Priya Sharma", street: "Unit 301, Business Park, Whitefield",
        city: "Bangalore", state: "Karnataka", pincode: "560066", phone: "+91 98765 43211",
        isDefault: false,
    },
];

export const brands = ["CleanPro", "SafeGuard", "EcoClean", "ShinePro", "MediClean", "WriteRight", "ClassicNote", "OfficeMate", "TeaLeaf", "EcoCup", "BrewBox", "SweetServe"];

export function getProductsByCategory(categorySlug: string): Product[] {
    return products.filter((p) => p.categorySlug === categorySlug);
}

export function getProductBySlug(slug: string): Product | undefined {
    return products.find((p) => p.slug === slug);
}

export function getCategoryBySlug(slug: string): Category | undefined {
    return categories.find((c) => c.slug === slug);
}

export function getFeaturedProducts(): Product[] {
    return products.filter((p) => p.isFeatured);
}
