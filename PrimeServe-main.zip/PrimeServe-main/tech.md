# PrimeServe — Technical Specification

> **Version**: 1.0 | **Updated**: 25 February 2026

---

## 1. Architecture Overview

```
┌─────────────────────────────────────────────────────────┐
│                      CLIENT (Browser)                   │
│  Next.js 14 App Router · React 18 · TypeScript          │
│  Tailwind CSS · shadcn/ui · Zustand · React Query       │
└──────────────────────────┬──────────────────────────────┘
                           │ HTTPS
┌──────────────────────────▼──────────────────────────────┐
│                   NEXT.JS SERVER                        │
│  API Routes · Server Components · Middleware            │
│  NextAuth.js · Rate Limiting · Zod Validation           │
├───────────┬───────────┬───────────┬───────────┬─────────┤
│  Airtable │   Redis   │Cloudinary │  Razorpay │  Zoho   │
│  (Data)   │  (Cache)  │ (Images)  │(Payments) │(Invoice)│
└───────────┴───────────┴───────────┴───────────┴─────────┘
```

**Pattern**: Monolithic Next.js application (API routes + SSR + static) deployed on Vercel.  
**Why**: Simpler DevOps, shared types between client/server, fast iteration for a small team.

---

## 2. Frontend Stack

### Core

| Tool | Version | Purpose |
|------|---------|---------|
| **Next.js** | 14+ | Framework (App Router, SSR, SSG, API routes) |
| **React** | 18+ | UI library |
| **TypeScript** | 5+ | Type safety |
| **Tailwind CSS** | 3.4+ | Utility-first styling |
| **shadcn/ui** | Latest | Accessible component primitives (built on Radix UI) |

### State & Data

| Tool | Purpose |
|------|---------|
| **Zustand** | Client state (cart, UI, auth session) |
| **TanStack Query (React Query)** | Server state caching, pagination, optimistic updates |
| **React Hook Form** | Form state management |
| **Zod** | Schema validation (shared with API) |

### Key Libraries

| Library | Purpose |
|---------|---------|
| `next-themes` | Dark/light mode |
| `embla-carousel-react` | Product carousels |
| `react-hot-toast` / `sonner` | Toast notifications |
| `lucide-react` | Icon set |
| `nuqs` | URL query state sync (filters, search, pagination) |
| `recharts` | Dashboard charts (account analytics) |
| `react-dropzone` | File uploads (credit application docs) |

### Rendering Strategy

| Page Type | Strategy | Example |
|-----------|----------|---------|
| Home page | SSG + ISR (revalidate 60s) | `/` |
| Category pages | SSG + ISR (revalidate 60s) | `/category/[slug]` |
| Product pages | SSG + ISR (revalidate 300s) | `/product/[slug]` |
| Search results | SSR | `/search?q=...` |
| Cart, Checkout | CSR (client only) | `/cart`, `/checkout` |
| Account dashboard | SSR (protected) | `/account/*` |
| Static pages | SSG | `/about`, `/contact`, `/services` |

---

## 3. Backend (Next.js API Routes)

### Route Structure

```
src/app/api/
├── auth/              # NextAuth.js handlers
│   └── [...nextauth]/route.ts
├── products/
│   ├── route.ts           # GET (list, filter, sort, paginate)
│   └── [slug]/route.ts    # GET (single product)
├── categories/
│   ├── route.ts           # GET (all categories)
│   └── [slug]/
│       └── products/route.ts  # GET (products by category)
├── cart/
│   ├── route.ts           # GET, POST (get cart, add item)
│   └── items/
│       └── [id]/route.ts  # PATCH, DELETE (update qty, remove)
├── orders/
│   ├── route.ts           # GET (list), POST (create)
│   └── [id]/route.ts      # GET (single order)
├── checkout/
│   ├── create-session/route.ts   # POST (Razorpay order)
│   └── verify-payment/route.ts  # POST (verify signature)
├── credit/
│   ├── route.ts           # GET (credit status)
│   └── apply/route.ts     # POST (credit application)
├── pro-plan/
│   ├── status/route.ts    # GET
│   ├── subscribe/route.ts # POST
│   └── cancel/route.ts    # POST
├── user/
│   ├── profile/route.ts   # GET, PATCH
│   └── addresses/
│       ├── route.ts       # GET, POST
│       └── [id]/route.ts  # PATCH, DELETE
├── favorites/
│   ├── route.ts           # GET, POST
│   └── [productId]/route.ts  # DELETE
├── reviews/
│   └── [productId]/route.ts   # GET, POST
├── search/route.ts        # GET (full-text search)
├── promo/validate/route.ts    # POST
└── admin/                 # Admin-only endpoints
    ├── products/route.ts
    ├── orders/route.ts
    ├── users/route.ts
    └── credit/route.ts
```

### API Conventions

- **Response format**: `{ success: boolean, data?: T, error?: string, meta?: { page, totalPages, total } }`
- **Validation**: Every request body validated with Zod before processing
- **Error codes**: Standard HTTP (400, 401, 403, 404, 422, 429, 500)
- **Pagination**: `?page=1&limit=24` → returns `meta.page`, `meta.totalPages`, `meta.total`
- **Filtering**: Query params — `?category=cleaning&brand=xyz&minPrice=500&maxPrice=2000&sort=price_asc`

### Middleware (`src/middleware.ts`)

```typescript
// Handles:
// 1. Auth session validation for protected routes (/account/*, /checkout/*, /api/cart/*, etc.)
// 2. Redirect unauthenticated users to /login?callbackUrl=...
// 3. Admin route protection (/admin/*, /api/admin/*)
// 4. Rate limiting headers
```

---

## 4. Authentication & Authorization

### Stack: NextAuth.js v5

**Providers (MVP)**:
- **Credentials** — email + password (bcrypt hashed)
- **Google OAuth** — one-click sign-in
- **Optional (Phase 2)**: OTP-based login via SMS

### Session Strategy

| Aspect | Choice |
|--------|--------|
| Session type | JWT (stateless, stored in HTTP-only cookie) |
| Token lifetime | Access: 15 min, Refresh: 30 days |
| Cookie flags | `HttpOnly`, `Secure`, `SameSite=Lax` |
| Refresh | Silent refresh via NextAuth callback |

### User Roles

| Role | Permissions |
|------|------------|
| `customer` | Browse, cart, checkout, manage own account, apply for credit |
| `admin` | All customer permissions + manage products, orders, users, credit approvals |
| `super_admin` | All admin + manage admins, system settings |

### Auth Flow

```
Register → Hash password (bcrypt, cost 12) → Store in DB → Auto-login → Redirect to /account
Login    → Verify credentials → Issue JWT → Set HTTP-only cookie → Redirect
OAuth    → Google consent → Callback → Create/link user → Issue JWT → Redirect
Logout   → Clear cookie → Redirect to /
```

### Route Protection

| Route Pattern | Access |
|---------------|--------|
| `/`, `/category/*`, `/product/*`, `/about`, `/contact`, `/services` | Public |
| `/cart`, `/checkout/*` | Authenticated |
| `/account/*` | Authenticated (own data only) |
| `/admin/*`, `/api/admin/*` | Admin role only |

---

## 5. Database (Airtable)

### Why Airtable

- **No-code backend**: Visual interface for managing products, orders, users — non-technical team members can view/edit data directly
- **REST API**: Well-documented API for CRUD operations from Next.js API routes
- **Built-in views**: Kanban (order status), gallery (products), calendar (deliveries) available out of the box
- **Integrations**: Native Zapier/Make connections for automation
- **Rapid MVP**: No database migrations, no schema files — add/rename fields instantly

### Access Pattern

```typescript
// All Airtable access goes through a server-side wrapper
// src/lib/server/airtable.ts
import Airtable from 'airtable';

const base = new Airtable({ apiKey: process.env.AIRTABLE_PAT }).base(
  process.env.AIRTABLE_BASE_ID!
);

// Table references
export const tables = {
  users:          base('Users'),
  products:       base('Products'),
  categories:     base('Categories'),
  brands:         base('Brands'),
  bulkPricing:    base('Bulk Pricing Tiers'),
  orders:         base('Orders'),
  orderItems:     base('Order Items'),
  cart:           base('Cart'),
  cartItems:      base('Cart Items'),
  addresses:      base('Addresses'),
  favorites:      base('Favorites'),
  reviews:        base('Reviews'),
  shoppingLists:  base('Shopping Lists'),
  creditAccounts: base('Credit Accounts'),
  proSubscriptions: base('Pro Subscriptions'),
  promoCodes:     base('Promo Codes'),
};
```

### Airtable Base — Tables & Fields

#### Users
| Field | Type | Notes |
|-------|------|-------|
| `Email` | Email (unique) | Primary lookup |
| `PasswordHash` | Single line text | bcrypt hash (null for OAuth users) |
| `Name` | Single line text | |
| `CompanyName` | Single line text | |
| `Phone` | Phone number | |
| `GSTNumber` | Single line text | |
| `Role` | Single select | `Customer`, `Admin`, `SuperAdmin` |
| `EmailVerified` | Checkbox | |
| `Image` | URL | Avatar / OAuth profile pic |
| `Orders` | Link to Orders | |
| `Addresses` | Link to Addresses | |
| `CreditAccount` | Link to Credit Accounts | |
| `ProSubscription` | Link to Pro Subscriptions | |

#### Products
| Field | Type | Notes |
|-------|------|-------|
| `Name` | Single line text | |
| `Slug` | Single line text (unique) | URL-friendly, auto-generated |
| `SKU` | Single line text (unique) | |
| `Description` | Long text (rich) | |
| `Specs` | Long text (JSON) | Key-value pairs |
| `Images` | Attachment | Cloudinary URLs stored as attachments |
| `BasePrice` | Number (integer) | In paise (₹100 = 10000) |
| `Stock` | Number (integer) | |
| `MinOrderQty` | Number | Default 1 |
| `MaxOrderQty` | Number | Optional |
| `Unit` | Single select | `piece`, `litre`, `kg`, `pack`, `box` |
| `IsActive` | Checkbox | |
| `Tags` | Multiple select | For search/filtering |
| `Category` | Link to Categories | |
| `Brand` | Link to Brands | |
| `BulkPricingTiers` | Link to Bulk Pricing Tiers | |
| `Reviews` | Link to Reviews | |

#### Categories
| Field | Type | Notes |
|-------|------|-------|
| `Name` | Single line text | |
| `Slug` | Single line text (unique) | |
| `Description` | Long text | |
| `ImageUrl` | URL | Category banner/icon |
| `ParentCategory` | Link to Categories | Self-referencing (sub-categories) |
| `Products` | Link to Products | |

#### Orders
| Field | Type | Notes |
|-------|------|-------|
| `OrderNumber` | Autonumber / Formula | e.g., `PS-2026-00001` |
| `User` | Link to Users | |
| `Address` | Link to Addresses | |
| `Status` | Single select | `Pending`, `Confirmed`, `Processing`, `Shipped`, `Delivered`, `Cancelled`, `Returned` |
| `Subtotal` | Number (integer) | Paise |
| `Discount` | Number (integer) | |
| `GST` | Number (integer) | |
| `ShippingCost` | Number (integer) | |
| `Total` | Formula | `Subtotal - Discount + GST + ShippingCost` |
| `PaymentMethod` | Single select | `Card`, `UPI`, `NetBanking`, `Wallet`, `CreditTerms`, `COD` |
| `RazorpayPaymentId` | Single line text | |
| `CreditUsed` | Checkbox | |
| `CreditDueDate` | Date | |
| `ProDiscount` | Checkbox | |
| `ZohoInvoiceId` | Single line text | Zoho Books invoice reference |
| `OrderItems` | Link to Order Items | |

#### Credit Accounts
| Field | Type | Notes |
|-------|------|-------|
| `User` | Link to Users (unique) | |
| `CreditLimit` | Number (integer) | Paise |
| `AvailableCredit` | Formula | `CreditLimit - SUM(outstanding orders)` |
| `Status` | Single select | `Pending`, `Approved`, `Suspended`, `Rejected` |
| `Documents` | Attachment | GST cert, bank statements, etc. |
| `ApprovedAt` | Date | |

#### Pro Subscriptions
| Field | Type | Notes |
|-------|------|-------|
| `User` | Link to Users (unique) | |
| `Plan` | Single select | `Monthly`, `Quarterly`, `Annual` |
| `Amount` | Number (integer) | Paise |
| `StartDate` | Date | |
| `EndDate` | Date | |
| `AutoRenew` | Checkbox | |
| `Status` | Single select | `Active`, `Cancelled`, `Expired` |
| `RazorpaySubscriptionId` | Single line text | |

> Additional tables (`Brands`, `Bulk Pricing Tiers`, `Cart`, `Cart Items`, `Order Items`, `Addresses`, `Favorites`, `Reviews`, `Shopping Lists`, `Promo Codes`) follow the same pattern.

### Airtable API Limits & Mitigations

| Constraint | Limit | Mitigation |
|------------|-------|------------|
| Rate limit | 5 req/sec per base | Redis cache layer for reads; batch writes |
| Records per table | 50,000 (free) / 500,000 (Team+) | Adequate for MVP; archive old orders if needed |
| Payload size | 100 records per list request | Paginate via `offset` parameter |
| Attachment size | 20MB per cell | Use Cloudinary URLs, not direct uploads |

### Caching (Redis)

Since Airtable has strict rate limits, Redis caching is **essential**:

| Key Pattern | TTL | Data |
|-------------|-----|------|
| `product:{slug}` | 5 min | Single product record |
| `products:{category}:{page}:{filters}` | 2 min | Paginated product list |
| `categories:all` | 10 min | All categories |
| `cart:{userId}` | 30 min | Cart contents |
| `user:{id}:credit` | 5 min | Credit account summary |
| `search:{hash}` | 2 min | Search results |
| `rate:{ip}` | 1 min | Rate limit counter |

**Cache invalidation**: Bust relevant cache keys on write operations (create/update/delete via API routes or Airtable webhook automations).

---

## 6. Payment Integration (Razorpay)

### Standard Payment Flow

```
1. Client: User clicks "Place Order"
2. Server: POST /api/checkout/create-session
   → Validate cart, calculate total, create Razorpay Order via API
   → Return razorpay_order_id to client
3. Client: Open Razorpay checkout modal (prefilled with order details)
   → User completes payment (Card, UPI, Net Banking, Wallet)
   → Razorpay returns: razorpay_payment_id, razorpay_order_id, razorpay_signature
4. Server: POST /api/checkout/verify-payment
   → Verify signature: HMAC-SHA256(order_id + "|" + payment_id, key_secret)
   → If valid: create Order in Airtable, deduct stock, trigger Zoho invoice, send confirmation
   → If invalid: return error, do not create order
```

### Credit Terms Payment Flow

```
1. User selects "Credit Terms" at checkout
2. Server validates: user has approved credit, available credit >= order total
3. Order created in Airtable with PaymentMethod=CreditTerms, CreditDueDate=now+45/60 days
4. CreditAccount AvailableCredit reduced by order total
5. Zoho Books invoice generated with due date (see Section 6a)
6. Razorpay Payment Link created for the invoice amount with due date
   → Link sent to customer via email/SMS for when they're ready to pay
7. Automated reminders at -7, 0, +3, +7 days from due date (via Zoho + SendGrid)
8. Customer pays via Razorpay Payment Link → webhook confirms → admin marks invoice paid → credit restored
```

### Razorpay for Pro Plan Subscriptions

```
1. User selects Pro plan tier (Monthly/Quarterly/Annual)
2. Server: Create Razorpay Subscription with appropriate plan_id
3. First charge captured → ProSubscription record created in Airtable
4. Recurring charges handled by Razorpay automatically
5. Webhooks notify our server on charge/failure/cancellation
```

### Razorpay Webhooks

| Event | Action |
|-------|--------|
| `payment.captured` | Confirm order, trigger Zoho invoice, send email |
| `payment.failed` | Mark order failed, notify user |
| `refund.processed` | Update order status, restore credit if applicable, Zoho credit note |
| `subscription.charged` | Renew Pro plan in Airtable |
| `subscription.cancelled` | Update Pro status in Airtable |
| `payment_link.paid` | Mark credit-terms invoice as paid, restore available credit |

---

## 6a. GST & Invoicing (Zoho Books)

### Why Zoho Books

- **GST-compliant** invoicing out of the box (GSTIN validation, HSN codes, e-invoicing)
- **REST API** for programmatic invoice creation from Next.js
- **Auto-generates** GST-compliant PDF invoices with company branding
- **Payment tracking** — matches payments to invoices
- **Reports** — GST returns (GSTR-1, GSTR-3B), P&L, balance sheet
- **Affordable** — Standard plan covers all B2B invoicing needs

### Integration Flow

```
1. Order confirmed (payment captured or credit terms selected)
2. Server: POST /api/zoho/create-invoice
   → Zoho Books API: Create Invoice
   → Include: customer details, GST number, line items with HSN codes, tax rates
   → Set due date: immediate (prepaid) or +45/60 days (credit terms)
3. Zoho generates GST-compliant PDF invoice
4. Store Zoho Invoice ID in Airtable Order record (ZohoInvoiceId field)
5. Invoice PDF link sent to customer via email
6. Customer can download invoice from Account Dashboard
```

### Zoho API Usage

```typescript
// src/lib/server/zoho.ts
const ZOHO_API = 'https://www.zohoapis.in/books/v3';

export async function createInvoice(order: Order, customer: User) {
  const invoice = await fetch(`${ZOHO_API}/invoices?organization_id=${ORG_ID}`, {
    method: 'POST',
    headers: {
      'Authorization': `Zoho-oauthtoken ${accessToken}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      customer_id: customer.zohoCustomerId,
      gst_no: customer.gstNumber,
      invoice_number: order.orderNumber,
      date: new Date().toISOString().split('T')[0],
      due_date: order.creditDueDate || new Date().toISOString().split('T')[0],
      line_items: order.items.map(item => ({
        name: item.productName,
        hsn_or_sac: item.hsnCode,
        quantity: item.quantity,
        rate: item.unitPrice / 100, // Convert paise to rupees
        tax_id: item.taxId, // GST tax rate (5%, 12%, 18%, 28%)
      })),
    }),
  });
  return invoice.json();
}
```

### Zoho Webhooks / Automations

| Event | Action |
|-------|--------|
| Invoice created | Send PDF to customer email |
| Payment recorded | Update Airtable order status, restore credit if applicable |
| Invoice overdue | Trigger reminder email via SendGrid |
| Credit note created | Process refund via Razorpay |

---

## 7. Image Management (Cloudinary)

### Upload Flow

```
1. Admin uploads product image via admin panel
2. Server: Cloudinary Upload API (signed upload from server, NOT client)
3. Store returned URL in Product Images attachment field (Airtable)
4. Serve via Cloudinary CDN with transformations
```

### Transformation Presets

| Context | Transformation | Size |
|---------|---------------|------|
| Product thumbnail (card) | `c_fill,w_400,h_400,q_80,f_auto` | ~30KB |
| Product gallery (PDP) | `c_fill,w_800,h_800,q_85,f_auto` | ~80KB |
| Product zoom | `c_fit,w_1600,h_1600,q_90,f_auto` | ~200KB |
| Category banner | `c_fill,w_1200,h_400,q_80,f_auto` | ~60KB |
| Thumbnail strip | `c_fill,w_100,h_100,q_70,f_auto` | ~5KB |

Use `next/image` with Cloudinary loader for automatic `srcset` and lazy loading.

---

## 8. Email System (SendGrid)

### Transactional Emails

| Trigger | Template | Recipients |
|---------|----------|-----------|
| Registration | Welcome + verify email | User |
| Order placed | Order confirmation + items | User |
| Order shipped | Shipping confirmation + tracking | User |
| Order delivered | Delivery confirmation + review prompt | User |
| Invoice generated | Invoice PDF attached | User |
| Credit approved | Credit limit details | User |
| Payment reminder | Due date + amount + pay link | User |
| Pro plan activated | Welcome + benefits + account manager | User |
| Pro plan expiring | Renewal reminder (7 days before) | User |
| New order (admin) | Order summary | Admin |
| Credit application | Review request | Admin |

---

## 9. Security Implementation

### Input Validation

```typescript
// Every API route follows this pattern:
import { z } from 'zod';

const createOrderSchema = z.object({
  addressId: z.string().cuid(),
  deliveryMethod: z.enum(['STANDARD', 'EXPRESS', 'SAME_DAY']),
  paymentMethod: z.enum(['CARD', 'UPI', 'NET_BANKING', 'WALLET', 'CREDIT_TERMS', 'COD']),
  promoCode: z.string().optional(),
});

// In route handler:
const body = createOrderSchema.parse(await req.json()); // throws on invalid
```

### Rate Limiting

| Route Group | Limit | Window |
|-------------|-------|--------|
| Auth endpoints | 10 req | 1 min |
| Search | 30 req | 1 min |
| Cart operations | 60 req | 1 min |
| General API | 100 req | 1 min |
| Admin API | 200 req | 1 min |

### Headers (via `next.config.ts`)

```
X-Content-Type-Options: nosniff
X-Frame-Options: DENY
X-XSS-Protection: 1; mode=block
Referrer-Policy: strict-origin-when-cross-origin
Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' https://checkout.razorpay.com; ...
Strict-Transport-Security: max-age=31536000; includeSubDomains
```

---

## 10. Testing Strategy

| Layer | Tool | Coverage Target |
|-------|------|----------------|
| Unit tests | Jest + React Testing Library | Components, hooks, utilities — 80% |
| API tests | Jest + supertest | All API routes — 90% |
| Integration | Playwright or Cypress | Critical flows (browse → cart → checkout) |
| Type checking | `tsc --noEmit` | 100% (CI gate) |
| Linting | ESLint + Prettier | 100% (CI gate) |

### CI Pipeline (GitHub Actions)

```
on push/PR → Install → Lint → Type Check → Unit Tests → Build → E2E Tests → Deploy Preview
on merge to main → All above → Deploy to Production (Vercel)
```

---

## 11. Monitoring & Observability

| Tool | Purpose |
|------|---------|
| **Sentry** | Error tracking, performance traces |
| **Vercel Analytics** | Web Vitals, page performance |
| **Google Analytics 4** | Traffic, conversions, user behavior |
| **UptimeRobot** | Uptime monitoring, alert on downtime |
| **Zoho Books Reports** | GST returns, revenue, outstanding invoices |

### Key Alerts

- Error rate > 1% in 5 min window → Slack + Email
- API p95 latency > 1s → Slack
- Payment webhook failure → Immediate email to admin
- Credit payment overdue > 7 days → Admin notification

---

## 12. Deployment

### Infrastructure

| Component | Service | Tier |
|-----------|---------|------|
| Frontend + API | Vercel (Pro) | Auto-scaling |
| Database | Airtable | Team plan (50,000+ records/table) |
| Cache | Upstash Redis | Serverless |
| Images | Cloudinary | Free tier (25GB) |
| Invoicing & GST | Zoho Books | Standard plan |
| DNS + CDN | Cloudflare | Free |
| Domain | Custom `.com` | — |

### Environment Setup

```
├── Development  → localhost:3000, Airtable dev base (duplicate of production)
├── Staging      → Vercel Preview (per PR), Airtable staging base
└── Production   → Vercel Production, Airtable production base
```

### Environment Variables

```env
# App
NEXT_PUBLIC_APP_URL=https://primeserve.com
NODE_ENV=production

# Airtable
AIRTABLE_PAT=pat...                    # Personal Access Token
AIRTABLE_BASE_ID=app...                 # Base ID from Airtable URL

# Cache
REDIS_URL=redis://...

# Auth
NEXTAUTH_SECRET=<random-64-char>
NEXTAUTH_URL=https://primeserve.com
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...

# Payments (Razorpay)
RAZORPAY_KEY_ID=rzp_live_...
RAZORPAY_KEY_SECRET=...
RAZORPAY_WEBHOOK_SECRET=...

# Invoicing (Zoho Books)
ZOHO_CLIENT_ID=...
ZOHO_CLIENT_SECRET=...
ZOHO_REFRESH_TOKEN=...
ZOHO_ORGANIZATION_ID=...

# Images
CLOUDINARY_CLOUD_NAME=...
CLOUDINARY_API_KEY=...
CLOUDINARY_API_SECRET=...

# Email
SENDGRID_API_KEY=SG....
SENDGRID_FROM_EMAIL=orders@primeserve.com

# Analytics
NEXT_PUBLIC_GA_ID=G-XXXXXXX
SENTRY_DSN=https://...@sentry.io/...
```

---

## 13. Project Setup Commands

```bash
# Initialize project
npx -y create-next-app@latest ./ --typescript --tailwind --eslint --app --src-dir

# Core dependencies
npm install airtable zustand @tanstack/react-query zod react-hook-form @hookform/resolvers next-auth@beta razorpay

# UI
npx shadcn@latest init
npm install lucide-react next-themes sonner embla-carousel-react nuqs recharts

# Dev dependencies
npm install -D @types/bcrypt jest @testing-library/react @testing-library/jest-dom

# No database migration needed — tables are managed visually in Airtable
# Go to https://airtable.com → create a new base → add tables per schema above
```

---

## 14. Folder Conventions

| Directory | Convention |
|-----------|-----------|
| `src/app/api/**` | One file per HTTP method group (`route.ts`) |
| `src/components/ui/` | shadcn primitives only — never edit directly, extend via wrapper |
| `src/components/[feature]/` | Feature components colocated with their types |
| `src/lib/` | Pure utilities, no React imports |
| `src/lib/server/airtable.ts` | Airtable client, table references, query helpers |
| `src/lib/server/zoho.ts` | Zoho Books API client (invoice CRUD, auth token refresh) |
| `src/lib/server/razorpay.ts` | Razorpay order creation, signature verification, webhooks |
| `src/lib/server/email.ts` | SendGrid email templates and sending |
| `src/hooks/` | Custom React hooks (`use-cart.ts`, `use-search.ts`) |
| `src/stores/` | Zustand stores (`cart-store.ts`, `ui-store.ts`) |
| `src/types/` | Shared TypeScript types/interfaces |
