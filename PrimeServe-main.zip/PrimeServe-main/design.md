# PrimeServe — Design System & UI Specification

> **Version**: 1.0 | **Updated**: 25 February 2026

---

## 1. Design Philosophy

| Principle | Description |
|-----------|-------------|
| **B2B-First** | Professional, efficient, information-dense — not consumer flashy |
| **Trust-Forward** | Every page reinforces reliability through badges, certifications, transparent pricing |
| **Desktop-First, Mobile-Optimized** | Most B2B users work on desktop; mobile must be fully functional for quick reorders |
| **Speed Over Delight** | Minimize clicks to purchase; fast task completion beats fancy animations |
| **Consistent & Predictable** | Same patterns everywhere — buttons, cards, forms, spacing — so users never feel lost |

---

## 2. Color System

### Brand Palette

| Token | Hex | HSL | Usage |
|-------|-----|-----|-------|
| `--primary` | `#1E3A8A` | `224 76% 33%` | Headers, primary buttons, links, nav active state |
| `--primary-light` | `#3B5FCC` | `224 58% 52%` | Hover states, secondary accents |
| `--primary-dark` | `#152A66` | `224 76% 24%` | Pressed states, footer background |
| `--secondary` | `#10B981` | `160 84% 39%` | Success indicators, Pro plan badges, growth metrics |
| `--secondary-light` | `#34D399` | `160 64% 52%` | Hover states |
| `--accent` | `#F59E0B` | `38 92% 50%` | CTAs, promotions, sale badges, star ratings |
| `--accent-light` | `#FBBF24` | `45 93% 56%` | Hover states |

### Semantic Colors

| Token | Light Mode | Dark Mode | Usage |
|-------|-----------|-----------|-------|
| `--background` | `#FFFFFF` | `#0F172A` | Page background |
| `--surface` | `#F8FAFC` | `#1E293B` | Cards, sidebar, panels |
| `--surface-elevated` | `#FFFFFF` | `#334155` | Modals, dropdowns, popovers |
| `--border` | `#E2E8F0` | `#334155` | Dividers, card borders, input borders |
| `--text-primary` | `#0F172A` | `#F1F5F9` | Headings, body text |
| `--text-secondary` | `#475569` | `#94A3B8` | Labels, descriptions, metadata |
| `--text-muted` | `#94A3B8` | `#64748B` | Placeholders, disabled text |
| `--success` | `#22C55E` | `#4ADE80` | In stock, order delivered, payment received |
| `--warning` | `#EAB308` | `#FACC15` | Low stock, expiring soon |
| `--error` | `#EF4444` | `#F87171` | Out of stock, validation errors, overdue |
| `--info` | `#3B82F6` | `#60A5FA` | Tooltips, informational badges |

### Usage Rules

- Primary CTAs: `--primary` background, white text
- Secondary CTAs: `--primary` border/text, transparent background
- Destructive actions: `--error` background
- Pro plan elements: `--accent` with gradient `linear-gradient(135deg, #F59E0B, #F97316)`
- Never place colored text on colored backgrounds without verifying contrast ≥ 4.5:1

---

## 3. Typography

### Font Stack

```css
--font-heading: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
--font-body: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
--font-mono: 'JetBrains Mono', 'Fira Code', 'Consolas', monospace;
```

> Load from Google Fonts: `Inter:wght@400;500;600;700`

### Type Scale

| Token | Size | Weight | Line Height | Usage |
|-------|------|--------|-------------|-------|
| `display` | 3rem (48px) | 700 | 1.1 | Hero headline only |
| `h1` | 2.25rem (36px) | 700 | 1.2 | Page titles |
| `h2` | 1.75rem (28px) | 600 | 1.3 | Section titles |
| `h3` | 1.375rem (22px) | 600 | 1.4 | Card titles, subsections |
| `h4` | 1.125rem (18px) | 600 | 1.4 | Small headings |
| `body-lg` | 1.125rem (18px) | 400 | 1.6 | Lead paragraphs |
| `body` | 1rem (16px) | 400 | 1.6 | Default body text |
| `body-sm` | 0.875rem (14px) | 400 | 1.5 | Table cells, form labels, metadata |
| `caption` | 0.75rem (12px) | 500 | 1.4 | Badges, timestamps, helper text |
| `price` | 1.5rem (24px) | 700 | 1.2 | Product prices on PDP |
| `price-sm` | 1rem (16px) | 600 | 1.2 | Product prices on cards |

### Rules

- All text uses `rem` units (no `px` for font sizes)
- Max paragraph width: `65ch` for readability
- Headings: no orphan words on important headlines (use `text-wrap: balance`)
- Product names: truncate to 2 lines with ellipsis on cards

---

## 4. Spacing & Layout

### Spacing Scale (8px base)

| Token | Value | Usage |
|-------|-------|-------|
| `--space-1` | 4px | Tight gaps (icon + label) |
| `--space-2` | 8px | Within compact components |
| `--space-3` | 12px | Between related items |
| `--space-4` | 16px | Default padding, form gaps |
| `--space-5` | 20px | Card padding |
| `--space-6` | 24px | Section internal spacing |
| `--space-8` | 32px | Between content blocks |
| `--space-10` | 40px | Between major sections |
| `--space-12` | 48px | Page section gaps |
| `--space-16` | 64px | Hero section padding |
| `--space-20` | 80px | Top-level section separation |

### Grid System

| Context | Config |
|---------|--------|
| **Page max-width** | `1280px` (centered, `px-4` on mobile, `px-8` on desktop) |
| **Product grid** | 4 columns @ desktop, 3 @ tablet, 2 @ mobile |
| **Category page** | Sidebar `280px` fixed + fluid main content |
| **Dashboard** | Sidebar `260px` + main content |
| **Checkout** | 2-column: main form `60%` + order summary `40%` |
| **Gap** | `24px` between grid items, `16px` on mobile |

### Breakpoints

| Name | Min-width | Typical devices |
|------|-----------|----------------|
| `sm` | 640px | Large phones (landscape) |
| `md` | 768px | Tablets |
| `lg` | 1024px | Small laptops |
| `xl` | 1280px | Desktops |
| `2xl` | 1536px | Large monitors |

---

## 5. Component Specifications

### 5.1 Buttons

| Variant | Background | Text | Border | Border Radius | Height |
|---------|-----------|------|--------|---------------|--------|
| **Primary** | `--primary` | white | none | 8px | 44px |
| **Secondary** | transparent | `--primary` | 1px `--primary` | 8px | 44px |
| **Ghost** | transparent | `--text-secondary` | none | 8px | 44px |
| **Destructive** | `--error` | white | none | 8px | 44px |
| **Pro CTA** | gradient (accent) | white | none | 8px | 48px |

- **Sizes**: `sm` (32px), `default` (44px), `lg` (48px)
- **Hover**: darken bg by 10%, lift `translateY(-1px)` + subtle shadow
- **Active**: darken bg by 15%, no lift
- **Disabled**: 50% opacity, `cursor-not-allowed`
- **Loading**: spinner icon replaces text, button width preserved
- **Touch target**: minimum 44×44px on mobile

### 5.2 Product Card

```
┌─────────────────────────┐
│  ❤ (favorite)     Badge │  ← "In Stock" / "Bulk Available"
│                         │
│      [Product Image]    │  ← hover: show alt image
│       400×400 ratio     │
│                         │
├─────────────────────────┤
│  ★★★★☆ (4.2) · 48      │  ← rating + review count
│  Product Name (2 lines) │
│  SKU: ABC-12345         │  ← text-muted
│                         │
│  ₹100 /unit             │  ← price, bold
│  From ₹80 for 100+      │  ← bulk hint, text-secondary
│                         │
│  [Add to Cart]          │  ← primary button, full width
│  [Quick View]           │  ← ghost button, full width
└─────────────────────────┘
```

- Card: `border-radius: 12px`, `border: 1px solid var(--border)`, `hover: shadow-lg + translateY(-2px)`
- Image: `aspect-ratio: 1/1`, `object-fit: cover`
- Transition: `all 200ms ease`

### 5.3 Forms

| Element | Style |
|---------|-------|
| **Input** | Height 44px, border 1px `--border`, radius 8px, padding 12px, focus ring 2px `--primary` |
| **Label** | `body-sm` weight 500, margin-bottom 6px |
| **Helper text** | `caption`, `--text-muted` |
| **Error text** | `caption`, `--error`, icon prefix |
| **Select** | Same as input + chevron icon right |
| **Checkbox** | 20×20px, rounded 4px, checked = `--primary` fill |
| **Radio** | 20×20px, circular, checked = `--primary` dot |
| **Textarea** | Same as input, min-height 100px, resize vertical |

### 5.4 Navigation (Header)

```
┌──────────────────────────────────────────────────────────────────┐
│  [Logo]  │  Categories ▼  │  [════ Search Bar ════]  │ ❤ 🛒(3) 👤│
│          │                │  "Search products, SKUs..." │         │
└──────────────────────────────────────────────────────────────────┘
│  Home  │  Housekeeping  │  Chemicals  │  Stationery  │  Pantry  │
└──────────────────────────────────────────────────────────────────┘
```

- Top bar: `height: 64px`, `sticky`, `z-index: 50`, white bg, bottom border
- Sub-nav (categories): `height: 48px`, `--surface` bg
- Mobile: hamburger menu → slide-in drawer from left
- Search: expands on focus, autocomplete dropdown below
- Cart icon: badge with item count (red circle, white text)

### 5.5 Badges & Tags

| Type | Style |
|------|-------|
| **In Stock** | `--success` bg (10% opacity) + `--success` text |
| **Low Stock** | `--warning` bg (10%) + `--warning` text |
| **Out of Stock** | `--error` bg (10%) + `--error` text |
| **Pro** | gradient `--accent` bg, white text, icon ⭐ |
| **Bulk Available** | `--info` bg (10%) + `--info` text |
| **New** | `--primary` bg, white text |
| **Sale** | `--error` bg, white text |
| **Verified Purchase** | `--success` bg (10%), checkmark icon |

All badges: `caption` size, `font-weight: 600`, `padding: 4px 8px`, `border-radius: 6px`

### 5.6 Modals & Drawers

- **Modal**: centered overlay, `max-width: 560px`, `border-radius: 16px`, backdrop blur (`backdrop-filter: blur(4px)`)
- **Quick View Modal**: `max-width: 900px`, 2-column (image left, info right)
- **Mobile Filter Drawer**: slides from bottom, `max-height: 85vh`, handle bar at top
- **Transition**: fade + scale up `150ms ease`
- **Close**: X button top-right + click outside + Escape key

---

## 6. Page-Specific Design Notes

### Home Page

| Section | Design Notes |
|---------|-------------|
| **Hero** | Full-width, `min-height: 500px`, gradient overlay on background image, centered text, 2 CTA buttons side-by-side |
| **Categories** | 4-card grid (2×2 on mobile), each card `aspect-ratio: 4/3`, image with dark gradient overlay, white text |
| **Benefits** | 4 icon cards in a row, icon in circle above, centered text below |
| **Featured Carousel** | Horizontal scroll, 4 visible cards on desktop, swipe on mobile, auto-play OFF |
| **Pro Teaser** | 2-column comparison card with accent gradient border, CTA button |
| **Testimonials** | 3-card slider, quote icon, company logo, author name + title |
| **Footer** | 4-column layout (About / Categories / Support / Contact), `--primary-dark` bg, light text |

### Category Page

| Element | Design Notes |
|---------|-------------|
| **Sidebar** | Sticky (`top: 80px`), scroll independently, collapsible filter groups |
| **Active filters** | Chips above grid, `X` to remove each, "Clear All" link |
| **Pagination** | Centered below grid, numbered pages, prev/next arrows |
| **Empty state** | Illustration + "No products found" + suggestion to adjust filters |

### Product Detail Page

| Element | Design Notes |
|---------|-------------|
| **Gallery** | 2-column: thumbnails vertical strip (left) + main image (right), click to swap |
| **Pricing table** | Striped table rows, highlight the tier matching current quantity |
| **Tabs** | Horizontal tab bar, underline active, sticky below header on scroll |
| **Reviews** | Rating breakdown bar chart, individual review cards with avatar |

### Cart Page

| Element | Design Notes |
|---------|-------------|
| **Cart table** | Full-width table on desktop, stacked cards on mobile |
| **Quantity selector** | `–` / input / `+` with min/max enforcement |
| **Summary sidebar** | Sticky on desktop, collapsible on mobile, prominent total |
| **Savings callout** | Green highlighted row showing bulk discount amount saved |

### Checkout

| Element | Design Notes |
|---------|-------------|
| **Step indicator** | Horizontal stepper — circles + lines, completed = `--primary`, active = outline, upcoming = muted |
| **Form layout** | Single column forms, labels above inputs, grouped fields |
| **Order summary** | Right sidebar (desktop), top accordion (mobile) |

### Account Dashboard

| Element | Design Notes |
|---------|-------------|
| **Sidebar nav** | Left sidebar with icon + label for each section, active = `--primary` bg (10%) |
| **Overview cards** | 4 stat cards in a row: Total Orders, Credit Available, Upcoming Deliveries, Pro Status |
| **Tables** | Striped rows, sortable columns, action buttons right-aligned |

---

## 7. Iconography

**Library**: [Lucide React](https://lucide.dev/) — consistent 24×24 stroke icons

| Context | Icons |
|---------|-------|
| Navigation | `Search`, `ShoppingCart`, `Heart`, `User`, `Menu`, `X` |
| Categories | `Brush` (housekeeping), `FlaskConical` (chemicals), `Pencil` (stationery), `Coffee` (pantry) |
| Status | `CheckCircle` (success), `AlertTriangle` (warning), `XCircle` (error), `Info` (info) |
| Actions | `Plus`, `Minus`, `Trash2`, `Edit`, `Download`, `Share2`, `Copy` |
| Account | `Package` (orders), `CreditCard` (payments), `MapPin` (addresses), `Star` (pro), `Settings` |

- Stroke width: `1.5px` default, `2px` for emphasis
- Size: `16px` inline with text, `20px` in buttons, `24px` standalone, `32px` in feature cards
- Color: inherits text color by default

---

## 8. Motion & Animation

| Interaction | Animation | Duration | Easing |
|-------------|-----------|----------|--------|
| Button hover | `translateY(-1px)` + shadow | 150ms | ease-out |
| Card hover | `translateY(-2px)` + shadow-lg | 200ms | ease-out |
| Modal open | Fade in + scale 0.95→1 | 200ms | ease-out |
| Modal close | Fade out + scale 1→0.95 | 150ms | ease-in |
| Dropdown open | Fade in + translateY(-4px→0) | 150ms | ease-out |
| Page transition | Fade in | 200ms | ease |
| Skeleton pulse | Opacity 0.5↔1 | 1.5s | ease-in-out (loop) |
| Toast slide-in | Slide from top-right | 300ms | spring |
| Add to cart | Button bounce + cart icon badge pulse | 300ms | spring |

### Rules

- No animation > 300ms (feel instant, not sluggish)
- Respect `prefers-reduced-motion`: disable all transforms, keep opacity transitions
- No auto-playing carousels (B2B users find them distracting)
- Loading states: skeleton screens (not spinners) for content areas; spinners only for buttons

---

## 9. Responsive Behavior

| Component | Desktop (≥1024px) | Tablet (768–1023px) | Mobile (<768px) |
|-----------|-------------------|--------------------|--------------------|
| Header | Full logo + search + icons | Logo + search + hamburger | Logo + hamburger |
| Product grid | 4 columns | 3 columns | 2 columns |
| Filter sidebar | Visible, sticky | Visible, collapsible | Hidden → bottom drawer |
| PDP layout | 2-column (gallery + info) | 2-column (stacked at sm) | Single column |
| Cart table | Full table | Full table | Stacked cards |
| Checkout | 2-column (form + summary) | 2-column | Single column, summary accordion |
| Dashboard | Sidebar + main content | Top nav + main | Bottom nav + main |
| Footer | 4 columns | 2×2 grid | Single column, accordions |

---

## 10. Accessibility Checklist

| Requirement | Implementation |
|-------------|---------------|
| Color contrast | All text ≥ 4.5:1, large text ≥ 3:1 (verified via shadcn defaults + custom tokens) |
| Focus indicators | 2px outline `--primary`, offset 2px, visible on all interactive elements |
| Keyboard nav | Tab order logical, Enter/Space activate, Escape closes modals, Arrow keys in menus |
| Screen readers | ARIA labels on icons, `aria-live` for cart updates/toast, semantic HTML throughout |
| Alt text | All product images have descriptive alt, decorative images use `alt=""` |
| Form errors | Linked via `aria-describedby`, announced on submit |
| Skip links | "Skip to main content" link visible on focus |
| Touch targets | Minimum 44×44px on all interactive elements |
| Reduced motion | `@media (prefers-reduced-motion: reduce)` disables transforms |

---

## 11. Dark Mode

- Toggle in header (sun/moon icon) via `next-themes`
- System preference respected on first visit
- All colors defined as CSS custom properties, swapped via `[data-theme="dark"]`
- Images: no special treatment (product photos stay as-is)
- Shadows: reduced opacity in dark mode
- Borders: switch to lighter shade (`--border` token handles this)

---

## 12. Loading & Empty States

### Skeleton Screens

- Match exact layout of the content they replace
- Rounded rectangles with pulse animation
- Used for: product cards, cart items, dashboard stats, order history rows

### Empty States

| Page | Message | Action |
|------|---------|--------|
| Cart | "Your cart is empty" | "Browse Products" button + recently viewed |
| Favorites | "No saved products yet" | "Explore Categories" button |
| Orders | "No orders placed yet" | "Start Shopping" button |
| Search (no results) | "No products match your search" | Suggestions + "Clear Filters" |
| Shopping Lists | "Create your first list" | "New List" button |

### Error States

- API error: toast notification + retry button
- 404: custom illustration + "Back to Home"
- 500: friendly message + "Try again" + support contact link
- Offline: banner at top "You're offline — some features may be unavailable"
