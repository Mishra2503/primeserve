# PrimeServe — Product Requirements Document (PRD)

> **Version**: 1.0  
> **Last Updated**: 25 February 2026  
> **Status**: Draft  

---

## 1. Executive Summary

**PrimeServe** is a B2B facility management marketplace that enables businesses to procure housekeeping materials, cleaning chemicals, office stationery, and pantry items through a single, streamlined digital platform. The platform differentiates itself through **flexible credit terms**, a **Pro subscription plan**, **tiered bulk pricing**, and a professional procurement experience built for repeat, high-volume B2B buyers.

### Problem Statement

Facility managers and procurement teams currently rely on fragmented supplier relationships, manual ordering via phone/email, and lack transparent pricing for bulk purchases. There is no single digital platform that combines product discovery, bulk pricing, credit terms, and subscription benefits tailored for the Indian B2B facility supplies market.

### Solution

A full-featured e-commerce marketplace with:
- Curated product catalog across 4 core categories
- Transparent tiered bulk pricing
- Built-in credit terms (45–60 days)
- Pro subscription plan with price lock, extra discounts, and dedicated support
- Multi-step checkout with B2B payment options (credit terms, UPI, net banking)
- Account dashboards with order history, credit management, and reordering tools

---

## 2. Target Users

### 2.1 Primary Personas

| Persona | Description | Goals | Pain Points |
|---------|-------------|-------|-------------|
| **Procurement Manager** | Mid-to-large company, manages vendor relationships & purchase orders | Find reliable supplier, get bulk discounts, track orders centrally | Fragmented suppliers, no price transparency, manual reordering |
| **Facility Manager** | Oversees building maintenance & supplies for offices/properties | Ensure consistent supply of cleaning & housekeeping materials | Stockouts, inconsistent quality, slow delivery |
| **Office Administrator** | Small-to-medium business, handles stationery & pantry restocking | Quick reordering, stay within budget, minimal procurement overhead | Time-consuming ordering, no credit terms available |

### 2.2 User Behavior Assumptions

- Users place **repeat orders** (weekly/monthly) with similar product lists
- Average order contains **10–30 line items**
- Most users browse on **desktop** during work hours; some use mobile for quick reorders
- Users expect **net payment terms** (not immediate payment) as standard in B2B
- Purchase decisions often involve **multiple stakeholders** (requester → approver)

---

## 3. Product Categories

| # | Category | Example Products | Approx. SKU Count (MVP) |
|---|----------|-----------------|------------------------|
| 1 | **Housekeeping Materials** | Mops, brooms, dustpans, trash bags, gloves, dusters, scrub pads | 80–120 |
| 2 | **Cleaning Chemicals** | Floor cleaners, glass cleaners, disinfectants, hand wash, toilet cleaners | 60–100 |
| 3 | **Office Stationery** | Pens, notebooks, staplers, markers, files, folders, tape, scissors | 100–150 |
| 4 | **Pantry Items** | Tea, coffee, sugar, disposable cups, napkins, snacks, water bottles | 70–100 |

**MVP total**: ~310–470 SKUs across 4 categories.

---

## 4. Feature Requirements

### 4.1 Home Page

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| H-1 | Hero section with value proposition | P0 | Headline, sub-headline, CTAs ("Browse Products", "Get Pro Plan", "Request Quote"), trust badges ("45-Day Credit", "24/7 Support", "Bulk Discounts") |
| H-2 | Category quick-access cards | P0 | 4 visual cards (one per category) with image, item count, "Explore →" link |
| H-3 | Key benefits section | P0 | 4 benefit cards: flexible payment, bulk discounts, fast delivery, account manager |
| H-4 | Featured products carousel | P1 | 8–12 trending/best-selling products, quick-add to cart |
| H-5 | Pro Plan teaser | P1 | Side-by-side Free vs Pro comparison, "Upgrade" CTA |
| H-6 | Client testimonials | P1 | 3–5 testimonials with company logos and quotes |
| H-7 | Search bar with autocomplete | P0 | Sticky header search, suggestions for products/categories/brands as user types |

### 4.2 Category / Product Listing Page

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| C-1 | Filter sidebar | P0 | Sub-category, brand (checkboxes), price range slider, rating, availability, bulk-available toggle, "Clear all" |
| C-2 | Sort options | P0 | Relevance, Price Low→High, Price High→Low, Newest, Best Selling |
| C-3 | Grid / List view toggle | P1 | Default grid; list view shows more detail per row |
| C-4 | Product card | P0 | Image (alt image on hover), name, SKU, unit price, bulk pricing indicator ("From ₹X for 50+"), quick-view button, add-to-cart, favorite heart, stock badge, rating |
| C-5 | Pagination | P0 | 24 products per page, numbered pages, "Showing X–Y of Z" |
| C-6 | Breadcrumb navigation | P0 | Home > Category > Sub-category |
| C-7 | Active filter chips | P1 | Show applied filters as removable chips above results |
| C-8 | Mobile filter drawer | P0 | Filters open as bottom sheet / drawer on mobile |

### 4.3 Product Detail Page (PDP)

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| P-1 | Image gallery | P0 | Large primary image, 4–6 thumbnails, zoom on hover |
| P-2 | Product info panel | P0 | Name, SKU, rating + review count, stock status, quantity selector (min/max enforced) |
| P-3 | Tiered pricing table | P0 | Display all bulk pricing tiers (e.g., 1–49 @ ₹100, 50–99 @ ₹90, 100+ @ ₹80) |
| P-4 | Add to Cart | P0 | Primary CTA, updates cart count in header |
| P-5 | Add to Favorites | P1 | Heart icon toggle |
| P-6 | Request Quote | P1 | Button for large/custom orders, opens form modal |
| P-7 | Product detail tabs | P0 | Overview, Technical Specs (table), Usage Instructions, Shipping & Returns, Reviews |
| P-8 | Reviews section | P1 | Star rating breakdown, individual reviews with verified badge, photo support |
| P-9 | Cross-sell sections | P1 | "Frequently Bought Together", "You May Also Like", "Recently Viewed" |

### 4.4 Shopping Cart

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| CT-1 | Cart table | P0 | Product image + name, SKU, unit price, editable quantity, subtotal, remove button |
| CT-2 | Real-time recalculation | P0 | Prices update instantly on quantity change; bulk discount applied automatically |
| CT-3 | Promo code field | P1 | Input + "Apply" button, show discount amount or error |
| CT-4 | Cart summary sidebar | P0 | Subtotal, bulk discount line, estimated GST, estimated shipping, order total, delivery date range, "Proceed to Checkout" CTA |
| CT-5 | Save for later | P1 | Move item out of cart into a saved list |
| CT-6 | Cart persistence | P0 | Cart saved to database for logged-in users, survives sessions and devices |
| CT-7 | Stock warnings | P0 | Warning badge if requested qty exceeds available stock |
| CT-8 | Empty cart state | P0 | Friendly message, category links, recently viewed products |

### 4.5 Checkout (Multi-Step)

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| CK-1 | Step 1 — Shipping | P0 | Company name (required), contact person, email, phone, full address, GST number (optional), saved address selector |
| CK-2 | Step 2 — Delivery method | P0 | Standard (3–5 days, free > ₹5,000), Express (1–2 days, ₹250), Same-day (₹500, location-dependent) |
| CK-3 | Step 3 — Payment | P0 | Card, UPI, net banking, wallet, Credit Terms (45/60 day with available limit shown), COD |
| CK-4 | Step 4 — Review & Place Order | P0 | Full summary, edit links per section, T&C checkbox, "Place Order" CTA |
| CK-5 | Order summary sidebar | P0 | Persistent across all steps, shows itemized list and price breakdown |
| CK-6 | Address validation | P1 | Pincode-based city/state auto-fill |
| CK-7 | Guest checkout | P2 | Allow order without account (collect email for tracking) |

### 4.6 User Account Dashboard

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| A-1 | Overview dashboard | P0 | Order stats, upcoming deliveries, recent orders, available credit, Pro status, quick reorder |
| A-2 | Order history | P0 | Sortable/filterable list, status tracking, download invoice, one-click reorder |
| A-3 | Saved addresses | P0 | CRUD operations, set default |
| A-4 | Payment methods | P1 | Save/manage cards, set default |
| A-5 | Favorites | P1 | List of saved products, move to cart, price drop alerts |
| A-6 | Shopping lists | P1 | Create named lists ("Monthly Supplies"), add products with quantities, reorder entire list |
| A-7 | Credit & invoices | P0 | Credit limit, available credit, outstanding balance, payment history, download statements |
| A-8 | Pro plan management | P1 | Plan details, upgrade/downgrade, billing history, auto-renewal toggle, cancel |
| A-9 | Account settings | P0 | Profile info, email preferences, notification settings, password change, company details |
| A-10 | Support | P1 | Contact form, FAQ links, ticket tracking |

### 4.7 Credit Terms System

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| CR-1 | Credit application flow | P0 | Available after 2–3 successful prepaid orders; user submits GST cert, business registration, bank statements, trade references |
| CR-2 | Credit approval | P0 | Admin reviews application, approves/rejects within 2–3 business days, assigns credit limit |
| CR-3 | Credit at checkout | P0 | Show available credit, auto-calculate due date (order date + 45 or 60 days), display in payment options |
| CR-4 | Invoice generation | P0 | PDF invoice generated on order completion with due date, downloadable from dashboard |
| CR-5 | Payment reminders | P1 | Email + SMS reminders at 7 days before, on due date, 3 days after, 7 days after |
| CR-6 | Overdue handling | P1 | Credit suspended after X days overdue, late fees (configurable), admin notification |

### 4.8 Pro Plan

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| PR-1 | Pro plan landing page | P1 | Full benefits breakdown, Free vs Pro comparison table, pricing tiers, enrollment CTA |
| PR-2 | Pricing tiers | P1 | Monthly ₹2,999 / Quarterly ₹7,999 (11% off) / Annual ₹29,999 (17% off) |
| PR-3 | Enrollment flow | P1 | Select tier → payment → immediate activation → welcome email with account manager details |
| PR-4 | Pro benefits applied automatically | P1 | +5% discount on all products, free delivery (no minimum), 60-day credit terms, price lock for 1 year |
| PR-5 | Pro dashboard widgets | P2 | Savings calculator, membership status, expiry date, renewal reminders, exclusive offers section |
| PR-6 | Auto-renewal & cancellation | P1 | Auto-renew on by default, cancel anytime with proration |

### 4.9 Search & Discovery

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| S-1 | Autocomplete search | P0 | Suggest products, categories, brands as user types (debounced, top 5–8 results) |
| S-2 | Search results page | P0 | Filtered results with same filter sidebar as category pages, "Did you mean?" for typos |
| S-3 | Search by SKU | P1 | Exact SKU match returns product directly |
| S-4 | Recent & trending searches | P2 | Show user's recent searches and platform-wide trending queries |
| S-5 | No-results state | P0 | Helpful message, category suggestions, contact support link |

### 4.10 Static / Informational Pages

| # | Requirement | Priority | Details |
|---|-------------|----------|---------|
| ST-1 | About Us | P1 | Company story, mission, product range overview, why choose us, certifications, client logos |
| ST-2 | Services | P1 | Product supply, bulk ordering, customized solutions, account management, consultation; each with CTA |
| ST-3 | Contact Us | P0 | Contact form (name, company, email, phone, subject dropdown, message, file attachment), direct contact info, Google Map embed, social links |
| ST-4 | Legal pages | P1 | Terms & Conditions, Privacy Policy, Refund & Return Policy, Shipping Policy, Credit Terms Agreement |

---

## 5. Non-Functional Requirements

### 5.1 Performance

| Metric | Requirement |
|--------|-------------|
| First Contentful Paint | < 1.5s |
| Largest Contentful Paint | < 2.5s |
| Time to Interactive | < 3.5s |
| Cumulative Layout Shift | < 0.1 |
| First Input Delay | < 100ms |
| Lighthouse Performance | ≥ 90 |
| API Response Time (p95) | < 500ms |

### 5.2 Scalability

- Handle **1,000 concurrent users** at launch
- Database designed for **50,000+ SKUs** (future)
- Order system supports **10,000+ orders/month**
- CDN for all static assets and product images

### 5.3 Security

| Requirement | Implementation |
|-------------|---------------|
| Data in transit | TLS 1.3 on all endpoints |
| Passwords | bcrypt (cost factor 12) or Argon2id |
| Payment data | PCI DSS via hosted payment fields (Razorpay/Stripe) — no card data on our servers |
| Authentication | JWT with HTTP-only secure cookies, refresh token rotation |
| Authorization | Role-based (customer, admin, super-admin) |
| Input validation | Server-side Zod schemas on every API route |
| Rate limiting | 100 req/min per IP on public routes, 30 req/min on auth routes |
| File uploads | Type whitelist (PDF, JPG, PNG), max 5MB |
| CSRF | Double-submit cookie pattern |
| XSS | Content Security Policy headers, React's built-in escaping |

### 5.4 Accessibility

- WCAG 2.1 Level AA compliance
- Keyboard navigable (all interactive elements)
- Screen reader compatible (ARIA labels, semantic HTML)
- Color contrast ratio ≥ 4.5:1
- Focus indicators visible
- Responsive text sizing (rem-based)

### 5.5 Browser Support

| Browser | Minimum Version |
|---------|----------------|
| Chrome | Last 2 versions |
| Firefox | Last 2 versions |
| Safari | Last 2 versions |
| Edge | Last 2 versions |
| Mobile Safari (iOS) | iOS 15+ |
| Chrome (Android) | Last 2 versions |

### 5.6 SEO

- Server-side rendering (Next.js) for all public pages
- Unique `<title>` and `<meta description>` per page
- Structured data (JSON-LD) for products, reviews, organization
- Semantic HTML (`<main>`, `<nav>`, `<article>`, `<section>`)
- XML sitemap auto-generated
- `robots.txt` configured
- Canonical URLs on all pages
- Open Graph and Twitter Card meta tags

---

## 6. User Flows

### 6.1 First-Time Buyer Flow

```
Landing Page → Browse Category → View Product → Add to Cart → Register/Login
→ Checkout (Address → Delivery → Payment [prepaid]) → Order Confirmation
→ Receive Order → Prompted to Apply for Credit Terms
```

### 6.2 Repeat Buyer Flow (with Credit)

```
Login → Dashboard → Reorder from Order History (or Shopping List)
→ Cart (pre-filled) → Checkout (saved address → delivery → Credit Terms payment)
→ Order Confirmation → Invoice Generated → Pay within 45/60 days
```

### 6.3 Pro Plan Enrollment Flow

```
See Pro Plan CTA (home/banner/dashboard) → Pro Plan Page (benefits comparison)
→ Select Tier (monthly/quarterly/annual) → Payment → Activation
→ Welcome Email + Account Manager Assigned → Pro benefits applied to all future orders
```

### 6.4 Credit Application Flow

```
Complete 2–3 prepaid orders → Credit Terms CTA appears in dashboard
→ Submit Application (GST cert, business docs, bank statements)
→ Admin Reviews (2–3 business days) → Approved → Credit limit assigned
→ Credit Terms available as payment option at checkout
```

---

## 7. Admin Panel Requirements (Phase 1 MVP)

| # | Feature | Priority | Details |
|---|---------|----------|---------|
| AD-1 | Product management | P0 | CRUD products, bulk import via CSV, manage images, set pricing tiers |
| AD-2 | Category management | P0 | CRUD categories and sub-categories |
| AD-3 | Order management | P0 | View/filter orders, update status (processing → shipped → delivered), generate invoices |
| AD-4 | User management | P0 | View users, approve/reject credit applications, adjust credit limits |
| AD-5 | Pro plan management | P1 | View subscribers, manage plans, handle cancellations |
| AD-6 | Promo code management | P1 | Create/edit/deactivate promo codes with rules (min order, max uses, expiry) |
| AD-7 | Dashboard analytics | P1 | Revenue, orders, top products, active users, credit utilization |
| AD-8 | Content management | P2 | Edit banners, testimonials, featured products |

---

## 8. Third-Party Integrations

| Integration | Purpose | Phase |
|-------------|---------|-------|
| **Razorpay** | Payment processing (cards, UPI, net banking, wallets) | MVP |
| **Cloudinary** | Product image upload, transformation, CDN delivery | MVP |
| **SendGrid** | Transactional emails (order confirmation, invoices, reminders) | MVP |
| **Google Analytics 4** | Traffic and conversion analytics | MVP |
| **MSG91 / Twilio** | SMS notifications (order updates, payment reminders) | Phase 2 |
| **Sentry** | Error tracking and monitoring | MVP |
| **Google Maps** | Address autocomplete, contact page map embed | MVP |
| **Mixpanel** | Product analytics, funnel tracking | Phase 2 |
| **Hotjar** | Heatmaps, session recordings | Phase 2 |
| **Tally / QuickBooks** | Accounting integration | Phase 3 |

---

## 9. Data & Analytics Requirements

### Key Events to Track

| Event | Properties |
|-------|-----------|
| `page_view` | page_name, category, referrer |
| `product_viewed` | product_id, category, price, source |
| `product_added_to_cart` | product_id, quantity, price, bulk_tier |
| `cart_viewed` | item_count, cart_total |
| `checkout_started` | item_count, cart_total, payment_method |
| `order_placed` | order_id, total, item_count, payment_method, credit_used, is_pro |
| `search_performed` | query, results_count, filters_applied |
| `pro_plan_viewed` | source_page |
| `pro_plan_subscribed` | tier, price |
| `credit_applied` | credit_limit_requested |
| `filter_applied` | filter_type, filter_value, category |

### Dashboards Needed

- **Executive**: Revenue, AOV, orders/day, new users, Pro adoption
- **Product**: Top sellers, slow movers, category performance, search queries
- **Customer**: Repeat rate, CLV, credit utilization, churn risk
- **Operations**: Fulfillment time, delivery success rate, return rate

---

## 10. Content Requirements

### Per Product (Data Fields)

| Field | Type | Required |
|-------|------|----------|
| Product name | String | Yes |
| SKU / Product code | String (unique) | Yes |
| Short description | String (≤ 160 chars) | Yes |
| Long description | Rich text | Yes |
| Category | Reference | Yes |
| Sub-category | Reference | No |
| Brand | Reference | Yes |
| Images | Array of URLs (min 3, max 8) | Yes |
| Base price (per unit, in paise) | Integer | Yes |
| Bulk pricing tiers | Array of {minQty, maxQty, price} | Yes |
| Unit of measurement | String (e.g., "piece", "litre", "kg") | Yes |
| Stock quantity | Integer | Yes |
| Minimum order quantity | Integer | Yes (default 1) |
| Maximum order quantity | Integer | No |
| Technical specifications | Key-value pairs | No |
| Usage instructions | Rich text | No (required for chemicals) |
| Safety data sheet URL | URL | No (required for chemicals) |
| Tags / Keywords | Array of strings | Yes |
| Is active | Boolean | Yes |

### Static Content Needed Before Launch

- [ ] Company About story (500–800 words)
- [ ] Service descriptions (200–300 words each × 5 services)
- [ ] Category descriptions (150–200 words each × 4 categories)
- [ ] Terms & Conditions
- [ ] Privacy Policy
- [ ] Refund & Return Policy
- [ ] Shipping Policy
- [ ] Credit Terms Agreement
- [ ] FAQ (20–30 questions)
- [ ] 3–5 client testimonials

---

## 11. Acceptance Criteria Summary

The MVP is considered complete when:

1. ✅ A user can browse all 4 categories, filter, sort, and search products
2. ✅ A user can view product details with images, specs, bulk pricing, and reviews
3. ✅ A user can add products to cart, edit quantities, and see real-time price updates
4. ✅ A user can complete checkout with shipping, delivery selection, and payment (Razorpay)
5. ✅ A user can register, log in, and manage their account (profile, addresses, order history)
6. ✅ A user can apply for credit terms after 2–3 prepaid orders
7. ✅ A user with approved credit can pay via credit terms at checkout
8. ✅ Invoices are auto-generated and downloadable
9. ✅ Admin can manage products, orders, users, and credit applications
10. ✅ Site loads in < 3s, scores 90+ on Lighthouse, is mobile-responsive
11. ✅ All pages have proper SEO (title, meta, structured data)
12. ✅ Payment processing is PCI-compliant via Razorpay hosted fields

---

## 12. Out of Scope (MVP)

The following are explicitly **not** in MVP and deferred to later phases:

- Mobile app (React Native / Flutter)
- Multi-language support
- AI-powered recommendations
- Approval workflows (multi-user company accounts)
- ERP / accounting integrations
- Vendor / supplier onboarding portal
- Barcode / QR scanner
- Real-time chat support (chatbot)
- Multi-currency support
- Inventory forecasting
- Procurement workflow (PO generation, budget approvals)

---

## 13. Risks & Mitigations

| Risk | Impact | Mitigation |
|------|--------|------------|
| Low initial product catalog | Users find limited selection | Seed MVP with 300+ SKUs across all 4 categories; prioritize best sellers |
| Credit defaults | Revenue loss | Start with conservative credit limits; require business documents; automated reminders |
| Slow adoption of Pro plan | Low subscription revenue | A/B test pricing; offer first-month free trial; highlight savings prominently |
| Complex checkout drop-off | Lost conversions | Minimize steps; auto-fill where possible; save progress; show progress indicator |
| Payment gateway downtime | Blocked orders | Integrate fallback gateway; show clear error messages; offer COD as backup |
| Content readiness | Delayed launch | Start content collection in Week 1; use placeholder content for soft launch if needed |

---

## Appendix A: Glossary

| Term | Definition |
|------|-----------|
| **SKU** | Stock Keeping Unit — unique product identifier |
| **GST** | Goods and Services Tax (India) |
| **AOV** | Average Order Value |
| **CLV** | Customer Lifetime Value |
| **MOQ** | Minimum Order Quantity |
| **PDP** | Product Detail Page |
| **CTA** | Call to Action |
| **RFQ** | Request for Quote |
| **Net Terms** | Credit-based payment where invoice is due X days after delivery |
| **Paise** | Smallest unit of Indian Rupee (1 ₹ = 100 paise) |
