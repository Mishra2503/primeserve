# PrimeServe – B2B Facility Management Marketplace

## Project Overview

PrimeServe is a comprehensive **B2B marketplace web application** for a facility management company that supplies housekeeping materials, cleaning chemicals, office stationery, and pantry items to business clients. The platform streamlines B2B procurement with professional features like flexible credit terms, subscription plans, and bulk ordering capabilities.

### Target Audience

| Segment | Role |
|---------|------|
| **Primary** | B2B clients — businesses, offices, facilities, property managers |
| **Secondary** | Procurement managers, facility managers, office administrators |
| **User Behavior** | Professional buyers seeking reliable suppliers, bulk orders, repeat purchases, credit terms |

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| **Framework** | Next.js 14+ (App Router) with TypeScript |
| **UI / Styling** | Tailwind CSS + shadcn/ui component library |
| **State Management** | Zustand (client state) + React Query / TanStack Query (server state) |
| **Forms** | React Hook Form + Zod validation |
| **Authentication** | NextAuth.js (or Clerk) |
| **Database** | PostgreSQL (via Prisma ORM) |
| **Caching** | Redis |
| **Payments** | Razorpay (Indian market primary) / Stripe (international) |
| **Image Storage** | Cloudinary (or AWS S3) |
| **Email** | SendGrid / AWS SES |
| **SMS** | Twilio / MSG91 |
| **Analytics** | Google Analytics 4, Mixpanel, Hotjar |
| **Error Tracking** | Sentry |
| **Deployment** | Vercel (frontend) / AWS (backend services) |
| **CI/CD** | GitHub Actions |

---

## Project Structure (Target)

```
prime-serve/
├── public/                    # Static assets, images, icons
├── src/
│   ├── app/                   # Next.js App Router pages
│   │   ├── (auth)/            # Auth routes (login, register)
│   │   ├── (shop)/            # Shop routes (home, categories, products)
│   │   ├── cart/              # Shopping cart
│   │   ├── checkout/          # Multi-step checkout
│   │   ├── account/           # User dashboard & settings
│   │   ├── about/             # About us page
│   │   ├── services/          # Services page
│   │   ├── contact/           # Contact us page
│   │   ├── pro-plan/          # Pro plan comparison & enrollment
│   │   ├── api/               # API routes
│   │   ├── layout.tsx         # Root layout
│   │   └── page.tsx           # Home page
│   ├── components/
│   │   ├── ui/                # shadcn/ui primitives
│   │   ├── layout/            # Header, Footer, Sidebar, Breadcrumbs
│   │   ├── home/              # Hero, CategoryCards, Testimonials, etc.
│   │   ├── product/           # ProductCard, ProductGallery, PricingTable
│   │   ├── cart/              # CartItem, CartSummary, PromoCode
│   │   ├── checkout/          # AddressForm, PaymentForm, OrderReview
│   │   ├── account/           # Dashboard widgets, OrderHistory, CreditPanel
│   │   └── shared/            # SearchBar, Filters, Pagination, Modals
│   ├── lib/                   # Utility functions, API clients, constants
│   ├── hooks/                 # Custom React hooks
│   ├── stores/                # Zustand stores (cart, auth, UI)
│   ├── types/                 # TypeScript type definitions
│   ├── styles/                # Global CSS, Tailwind config extensions
│   └── config/                # App config, env variables schema
├── prisma/
│   └── schema.prisma          # Database schema
├── tests/                     # Jest + React Testing Library + Cypress
├── .env.local                 # Environment variables (not committed)
├── tailwind.config.ts
├── next.config.ts
├── tsconfig.json
└── package.json
```

---

## Core Pages & Features

### 1. Home Page (`/`)
- **Hero Section** — headline emphasizing B2B benefits (bulk pricing, credit terms, reliable supply), CTAs: "Browse Products" / "Get Pro Plan" / "Request Quote", trust badges
- **Category Quick Access** — 4 large visual category cards: Housekeeping Materials, Cleaning Chemicals, Office Stationery, Pantry Items
- **Key Benefits** — flexible payment terms, bulk discounts, same/next-day delivery, dedicated account manager
- **Featured Products Carousel** — trending/best-selling items with quick-add to cart
- **Pro Plan Teaser** — Free vs Pro comparison, "Upgrade to Pro" CTA
- **Client Testimonials** — logos, success stories
- **Footer** — quick links, contact info, business hours, payment methods

### 2. Category Pages (`/category/[slug]`)
Four main categories: `housekeeping-materials`, `cleaning-chemicals`, `office-stationery`, `pantry-items`
- **Left Sidebar Filters** — sub-categories, brand, price range slider, ratings, availability, bulk quantity toggle, clear all
- **Main Content** — breadcrumbs, category banner, sort (relevance / price / newest / best-selling), grid/list toggle, pagination
- **Product Cards** — image (hover for alt image), name, SKU, unit price, bulk pricing indicator, quick view, add to cart, favorites, stock badge, rating stars

### 3. Product Detail Page (`/product/[slug]`)
- **Image Gallery** — large primary image, thumbnails (4-6), zoom on hover
- **Product Info** — name, SKU, rating, tiered bulk pricing table, stock status, quantity selector, Add to Cart, Add to Favorites, Request Quote
- **Tabs** — Overview, Technical Specs, Usage Instructions, Shipping & Returns, Reviews & Ratings
- **Cross-sell** — "Frequently Bought Together", "You May Also Like", "Recently Viewed"

### 4. Shopping Cart (`/cart`)
- Editable quantity table with SKU, unit price, subtotal, remove
- Promo code field, save for later
- Sticky sidebar: subtotal, bulk discount, estimated GST, shipping, order total, delivery date range
- Auto-save for logged-in users, stock warnings

### 5. Checkout (`/checkout`)
Multi-step flow:
1. **Shipping** — company name, contact person, address, GST number, saved addresses
2. **Delivery Method** — standard (free > ₹5,000), express, same-day
3. **Payment** — card, UPI, net banking, wallet, credit terms (45-day free / 60-day Pro), COD
4. **Review Order** — full summary, edit buttons, place order

### 6. About Us (`/about`)
Hero, company story, product range, why choose us, client logos, team section, certifications

### 7. Services (`/services`)
Product supply, bulk ordering, customized solutions, account management, consultation services, CTAs for quote/consultation/sales

### 8. Contact Us (`/contact`)
Form (name, company, email, phone, subject dropdown, message, file attachment), direct contact info, Google Map embed, social media links

### 9. User Account Dashboard (`/account`)
- Overview (stats, deliveries, recent orders, credit, Pro status)
- Order History (filter, sort, reorder, download invoices)
- Saved Addresses
- Payment Methods
- Favorites / Wishlist
- Shopping Lists (recurring order templates)
- Credit & Invoices
- Pro Plan Management
- Account Settings
- Support & Help

### 10. Pro Plan Page (`/pro-plan`)
Benefits comparison, pricing tiers (monthly ₹2,999 / quarterly ₹7,999 / annual ₹29,999), enrollment flow

---

## Business Logic

### Credit Terms System
| Feature | Free Plan | Pro Plan |
|---------|-----------|----------|
| Credit Terms | 45 days | 60 days |
| Credit Limit | Based on history | Higher limits |
| Application | After 2-3 successful orders | Immediate on subscription |

**Credit Application Flow**: Initial advance payment → 2-3 successful orders → submit GST certificate, business registration, bank statements, trade references → approval in 2-3 business days → credit limit assigned.

### Pro Plan Benefits
| Feature | Free | Pro |
|---------|------|-----|
| Credit Terms | 45 days | 60 days |
| Price Lock | No | 1 year |
| Free Delivery | ₹5,000+ | All orders |
| Extra Discount | — | +5% |
| Account Manager | No | Yes |
| Support | Email (24h) | Priority 24/7 |
| Returns | Standard | Free |
| Offers | General | Exclusive |

### Bulk Pricing (Tiered Example)
```
1–49 units:   ₹100/unit
50–99 units:  ₹90/unit
100+ units:   ₹80/unit
```

---

## Design System

### Color Palette
| Role | Hex | Usage |
|------|-----|-------|
| Primary | `#1E3A8A` | Trust, reliability — headers, primary buttons |
| Secondary | `#10B981` | Sustainability, growth — accents |
| Accent | `#F59E0B` | CTAs, promotions |
| Neutrals | `#F9FAFB` → `#111827` | Backgrounds, text |
| Success | `#22C55E` | Confirmations |
| Warning | `#FDE047` | Alerts |
| Error | `#EF4444` | Errors, destructive actions |

### Typography
- **Headings**: Inter / Poppins / Montserrat (professional sans-serif)
- **Body**: Open Sans / Roboto / system fonts
- **Scale**: H1 `2.5rem`, H2 `2rem`, H3 `1.5rem`, Body `1rem`, Small `0.875rem`

### Spacing
Base unit: `8px`. Scale: 8, 16, 24, 32, 48, 64, 96px.

### Design Principles
- **B2B-first**: efficiency over aesthetics, information density, professional tone, desktop-first (mobile-optimized)
- **Trust signals**: certifications, secure badges, transparent pricing
- **WCAG 2.1 AA**: 4.5:1 contrast, keyboard nav, screen reader support, focus indicators

---

## Database Schema (Key Entities)

```
User             → id, email, passwordHash, role, companyName, gstNumber, phone, createdAt
Address          → id, userId, label, companyName, contactPerson, street, city, state, pincode, isDefault
Product          → id, name, slug, sku, description, specs, categoryId, brandId, images[], basePrice, stock, isActive
Category         → id, name, slug, description, imageUrl, parentId (self-referencing for sub-categories)
Brand            → id, name, slug, logoUrl
BulkPricingTier  → id, productId, minQty, maxQty, pricePerUnit
Cart             → id, userId, items[] (productId, quantity)
Order            → id, userId, addressId, items[], subtotal, discount, gst, shipping, total, status, paymentMethod, creditTermsDays, dueDate, createdAt
Invoice          → id, orderId, invoiceNumber, pdfUrl, dueDate, paidAt, status
CreditAccount    → id, userId, creditLimit, availableCredit, status
ProSubscription  → id, userId, plan (monthly/quarterly/annual), startDate, endDate, status, autoRenew
Review           → id, productId, userId, rating, title, body, images[], isVerified, createdAt
Favorite         → id, userId, productId
ShoppingList     → id, userId, name, items[] (productId, quantity)
PromoCode        → id, code, discountType, discountValue, minOrderValue, maxUses, expiresAt
```

---

## API Routes (Key Endpoints)

```
Auth:       POST /api/auth/register, POST /api/auth/login, POST /api/auth/logout
Products:   GET  /api/products, GET /api/products/[slug], GET /api/products/search
Categories: GET  /api/categories, GET /api/categories/[slug]/products
Cart:       GET  /api/cart, POST /api/cart/items, PATCH /api/cart/items/[id], DELETE /api/cart/items/[id]
Orders:     POST /api/orders, GET /api/orders, GET /api/orders/[id]
Checkout:   POST /api/checkout/create-session, POST /api/checkout/verify-payment
Credit:     GET  /api/credit, POST /api/credit/apply
Pro Plan:   GET  /api/pro-plan/status, POST /api/pro-plan/subscribe, POST /api/pro-plan/cancel
Reviews:    GET  /api/reviews/[productId], POST /api/reviews
User:       GET  /api/user/profile, PATCH /api/user/profile, GET /api/user/addresses, POST /api/user/addresses
Favorites:  GET  /api/favorites, POST /api/favorites, DELETE /api/favorites/[productId]
Search:     GET  /api/search?q=...&category=...&brand=...&minPrice=...&maxPrice=...&sort=...
```

---

## Environment Variables

```env
# Database
DATABASE_URL=postgresql://...
REDIS_URL=redis://...

# Auth
NEXTAUTH_SECRET=
NEXTAUTH_URL=http://localhost:3000

# Payments
RAZORPAY_KEY_ID=
RAZORPAY_KEY_SECRET=
STRIPE_SECRET_KEY=
STRIPE_PUBLISHABLE_KEY=

# Storage
CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=

# Email & SMS
SENDGRID_API_KEY=
TWILIO_ACCOUNT_SID=
TWILIO_AUTH_TOKEN=

# Analytics
NEXT_PUBLIC_GA_ID=
MIXPANEL_TOKEN=

# Error Tracking
SENTRY_DSN=
```

---

## Development Guidelines

### Code Conventions
- Use **TypeScript** strict mode everywhere
- Follow **ESLint** + **Prettier** configuration
- Use **named exports** (avoid default exports except for pages)
- Colocate related files (component + styles + tests + types)
- Prefix server-only utilities with `server-` or place in `lib/server/`
- Use `zod` schemas for all API request/response validation
- All prices stored in **paise** (smallest currency unit) in the database

### Component Patterns
- Use shadcn/ui as the base; customize via Tailwind
- Server Components by default; Client Components only when needed (`"use client"`)
- Extract reusable hooks into `src/hooks/`
- Keep components < 150 lines; extract sub-components when larger

### Git Workflow
- `main` — production-ready code
- `develop` — integration branch
- Feature branches: `feature/<short-description>`
- Commit messages: Conventional Commits (`feat:`, `fix:`, `chore:`, `docs:`)

### Testing Strategy
- **Unit**: Jest + React Testing Library for components and utilities
- **Integration**: API route testing with supertest
- **E2E**: Cypress for critical user flows (browse → cart → checkout → order)
- **Target**: 80%+ code coverage on business logic

---

## Performance Targets

| Metric | Target |
|--------|--------|
| Page Load | < 3 seconds |
| Time to Interactive | < 5 seconds |
| Lighthouse Score | 90+ |
| Core Web Vitals | All green |
| PWA | Capable |

---

## Development Phases

### Phase 1 — MVP (Weeks 1–10)
Setup, auth, home page, 4 category pages, PDP, search, cart, checkout, payment integration, user accounts, order management, testing, soft launch.

### Phase 2 — Enhanced Features (Weeks 11–18)
Credit terms system, Pro plan subscription, advanced filtering, wishlist/favorites, bulk pricing display, invoice generation.

### Phase 3 — Advanced (Weeks 19–28)
Mobile app, analytics dashboard, automated reordering, ERP API integration, vendor onboarding, multi-location support, procurement workflows.

### Phase 4 — Scale (Ongoing)
AI recommendations, inventory forecasting, NLP search, multi-language, international expansion, advanced fintech.

---

## Success Metrics (First 3 Months)

| Category | Metric | Target |
|----------|--------|--------|
| Acquisition | Registered accounts | 500+ |
| Acquisition | Monthly active users | 2,000+ |
| Conversion | Cart-to-purchase | > 15% |
| Conversion | Overall conversion | > 2% |
| Revenue | Average Order Value | ₹15,000+ |
| Revenue | Monthly revenue | ₹20,00,000+ |
| Engagement | Session duration | > 3 min |
| Engagement | Bounce rate | < 50% |
| Pro Plan | Adoption rate | 10% of active users |

---

## Security Requirements

- SSL/TLS encryption on all routes
- PCI DSS compliance for payment data (via Razorpay/Stripe hosted fields)
- Passwords hashed with bcrypt / Argon2
- Optional 2FA for business accounts
- CSRF protection, XSS prevention, SQL injection prevention (Prisma parameterized queries)
- Rate limiting on API routes
- Secure file uploads with type/size validation
- GST number verification
- Session management with HTTP-only cookies

---

## Key References

| Reference | Purpose |
|-----------|---------|
| [Jumbotail](https://jumbotail.com) | B2B marketplace model, fintech integration |
| [Amazon Business](https://business.amazon.com) | Procurement features |
| [Udaan](https://udaan.com) | B2B India, mobile-first |
| [Moglix](https://moglix.com) | Industrial supplies UX |
| [shadcn/ui](https://ui.shadcn.com) | Component library |
| [Next.js Docs](https://nextjs.org/docs) | Framework reference |
| [Tailwind CSS](https://tailwindcss.com/docs) | Styling reference |
| [Prisma](https://prisma.io/docs) | ORM reference |
| [Razorpay Docs](https://razorpay.com/docs) | Payment integration |
